# PDOK Selectie Importeren

QGIS 3.44+ Processing-plugin, opgebouwd uit het aangeleverde `PDOK importeren` script.

## Installatie
Installeer de ZIP via **Plugins > Manage and Install Plugins > Install from ZIP**.

Daarna staat het algoritme in de Processing Toolbox als **PDOK - importeren**.

## BAG
Beschikbaar:
- Pand
- Verblijfsobject
- Adres
- Ligplaats
- Standplaats
- Woonplaats

Ook de bestaande BRK-perceel- en BGT-lagen zijn behouden.

De bestaande project/projectgebied-logica, EPSG:28992, batching, GeoPackage-opslag,
clipping en retry-logica zijn ongewijzigd overgenomen.
