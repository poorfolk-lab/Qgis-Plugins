# -*- coding: utf-8 -*-
def classFactory(iface):
    from .plugin import PdokSelectieImporterenPlugin
    return PdokSelectieImporterenPlugin(iface)
