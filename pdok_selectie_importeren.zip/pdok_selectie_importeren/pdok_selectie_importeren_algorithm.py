# -*- coding: utf-8 -*-

"""
QGIS Processing script: PDOK  importeren 

Plaats dit bestand in QGIS via:
Processing Toolbox > Scripts > Create New Script...
Plak/vervang met deze volledige inhoud en sla op als bijvoorbeeld:

pdok_selectie_importeren_groot_v6.py

Gebruik:
- Kies een polygoonlaag.
- Kies de kolom met Project.
- Kies de kolom met Projectgebied.
- Laat 'Alleen geselecteerde polygonen gebruiken' uit bij losse bestanden.
- Zet deze optie alleen aan bij een actieve projectlaag met selectie.
- Vink de PDOK-lagen aan die je wilt ophalen.
- Resultaatlagen worden automatisch aan het project toegevoegd.
- Optioneel kun je alles naar één GeoPackage wegschrijven.
"""

from qgis.PyQt.QtCore import QCoreApplication, QVariant

from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeature,
    QgsFeatureRequest,
    QgsField,
    QgsGeometry,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterFileDestination,
    QgsProject,
    NULL,
    QgsVectorFileWriter,
    QgsVectorLayer,
    QgsWkbTypes,
)

import json
import os
import tempfile
import time
import urllib.parse
import urllib.request
import urllib.error


class PdokSelectieImporterenAlgorithm(QgsProcessingAlgorithm):

    INPUT_POLYGON = "INPUT_POLYGON"
    SELECTED_ONLY = "SELECTED_ONLY"
    PROJECT_FIELD = "PROJECT_FIELD"
    PROJECT_AREA_FIELD = "PROJECT_AREA_FIELD"
    MERGE_BY_PROJECT = "MERGE_BY_PROJECT"
    PDOK_LAYERS = "PDOK_LAYERS"
    EXACT_CLIP = "EXACT_CLIP"
    OUTPUT_GPKG = "OUTPUT_GPKG"

    TARGET_CRS = QgsCoordinateReferenceSystem("EPSG:28992")

    PAGE_LIMIT = 1000
    MAX_FEATURES_PER_LAYER = 11000000

    # label, key, service_type, endpoint/collection
    LAYER_OPTIONS = [
        (
            "BAG - Pand",
            "bag_pand",
            "bag_ogcapi",
            "pand",
        ),
        (
            "BAG - Verblijfsobject",
            "bag_verblijfsobject",
            "bag_ogcapi",
            "verblijfsobject",
        ),
        (
            "BAG - Adres",
            "bag_adres",
            "bag_ogcapi",
            "adres",
        ),
        (
            "BAG - Ligplaats",
            "bag_ligplaats",
            "bag_ogcapi",
            "ligplaats",
        ),
        (
            "BAG - Standplaats",
            "bag_standplaats",
            "bag_ogcapi",
            "standplaats",
        ),
        (
            "BAG - Woonplaats",
            "bag_woonplaats",
            "bag_ogcapi",
            "woonplaats",
        ),

        (
            "BRK - Perceel",
            "brk_perceel",
            "wfs",
            "kadastralekaart:Perceel",
        ),

        (
            "BGT - Wegdeel",
            "bgt_wegdeel",
            "bgt_ogcapi",
            "wegdeel",
        ),
        (
            "BGT - Ondersteunend wegdeel",
            "bgt_ondersteunendwegdeel",
            "bgt_ogcapi",
            "ondersteunendwegdeel",
        ),

        (
            "BGT - Waterdeel (WTD)",
            "bgt_waterdeel",
            "bgt_ogcapi",
            "waterdeel",
        ),
        (
            "BGT - Ondersteunend waterdeel (OWT)",
            "bgt_ondersteunendwaterdeel",
            "bgt_ogcapi",
            "ondersteunendwaterdeel",
        ),
    ]

    OGC_BASES = {
        "bag_ogcapi":
            "https://api.pdok.nl/kadaster/bag/ogc/v2/collections/{collection}/items",

        "bgt_ogcapi":
            "https://api.pdok.nl/lv/bgt/ogc/v1/collections/{collection}/items",
    }

    BRK_WFS = (
        "https://service.pdok.nl/"
        "kadaster/kadastralekaart/wfs/v5_0"
    )

    def tr(self, string):
        return QCoreApplication.translate(
            "PdokSelectieImporteren",
            string,
        )

    def createInstance(self):
        return PdokSelectieImporterenAlgorithm()

    def name(self):
        return "pdok_selectie_importeren_groot_v6"

    def displayName(self):
        return self.tr(
            "PDOK - importeren"
        )

    def group(self):
        return self.tr("PDOK")

    def groupId(self):
        return "pdok"

    def shortHelpString(self):
        return self.tr(
            "Haalt aanvinkbare PDOK-lagen op binnen één of meer polygonen. "
            "Kies een Project-veld en Projectgebied-veld uit de invoerlaag. "
            "Zonder samenvoegen worden resultaten per Projectgebied opgeslagen; "
            "met 'Samenvoegen per Project' worden alle polygonen met dezelfde "
            "Project-waarde naar dezelfde resultaatlaag geschreven. "
            "Iedere PDOK-batch wordt tussentijds direct naar GeoPackage opgeslagen."
        )

    def initAlgorithm(self, config=None):

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUT_POLYGON,
                self.tr("Selectiepolygoonlaag"),
                [QgsProcessing.TypeVectorPolygon],
            )
        )

        self.addParameter(
            QgsProcessingParameterField(
                self.PROJECT_FIELD,
                self.tr("Kolom met Project"),
                parentLayerParameterName=self.INPUT_POLYGON,
                type=QgsProcessingParameterField.Any,
                allowMultiple=False,
            )
        )

        self.addParameter(
            QgsProcessingParameterField(
                self.PROJECT_AREA_FIELD,
                self.tr("Kolom met Projectgebied"),
                parentLayerParameterName=self.INPUT_POLYGON,
                type=QgsProcessingParameterField.Any,
                allowMultiple=False,
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.MERGE_BY_PROJECT,
                self.tr("Samenvoegen per Project"),
                defaultValue=False,
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.SELECTED_ONLY,
                self.tr("Alleen geselecteerde polygonen gebruiken"),
                defaultValue=False,
            )
        )

        self.addParameter(
            QgsProcessingParameterEnum(
                self.PDOK_LAYERS,
                self.tr("PDOK-lagen ophalen"),
                options=[
                    item[0]
                    for item in self.LAYER_OPTIONS
                ],
                allowMultiple=True,
                defaultValue=[0, 1, 6],
            )
        )

        self.addParameter(
            QgsProcessingParameterBoolean(
                self.EXACT_CLIP,
                self.tr("Objecten exact knippen op polygoon"),
                defaultValue=False,
            )
        )

        gpkg_param = QgsProcessingParameterFileDestination(
            self.OUTPUT_GPKG,
            self.tr(
                "Optioneel: schrijf resultaten naar GeoPackage"
            ),
            fileFilter="GeoPackage (*.gpkg)",
            optional=True,
        )

        self.addParameter(gpkg_param)

    def processAlgorithm(
        self,
        parameters,
        context,
        feedback,
    ):

        source = self.parameterAsSource(
            parameters,
            self.INPUT_POLYGON,
            context,
        )

        if source is None:
            raise QgsProcessingException(
                "Geen geldige polygoonlaag gekozen."
            )

        project_field = self.parameterAsString(
            parameters,
            self.PROJECT_FIELD,
            context,
        )

        project_area_field = self.parameterAsString(
            parameters,
            self.PROJECT_AREA_FIELD,
            context,
        )

        merge_by_project = self.parameterAsBool(
            parameters,
            self.MERGE_BY_PROJECT,
            context,
        )

        selected_only = self.parameterAsBool(
            parameters,
            self.SELECTED_ONLY,
            context,
        )

        layer_indices = self.parameterAsEnums(
            parameters,
            self.PDOK_LAYERS,
            context,
        )

        exact_clip = self.parameterAsBool(
            parameters,
            self.EXACT_CLIP,
            context,
        )

        output_gpkg = self.parameterAsFileOutput(
            parameters,
            self.OUTPUT_GPKG,
            context,
        )

        if not project_field:
            raise QgsProcessingException(
                "Kies de kolom met Project."
            )

        if not project_area_field:
            raise QgsProcessingException(
                "Kies de kolom met Projectgebied."
            )

        if not layer_indices:
            raise QgsProcessingException(
                "Vink minimaal één PDOK-laag aan."
            )

        project_idx = source.fields().indexFromName(
            project_field
        )

        project_area_idx = source.fields().indexFromName(
            project_area_field
        )

        if project_idx < 0:
            raise QgsProcessingException(
                f"Project-kolom '{project_field}' "
                "bestaat niet in de invoerlaag."
            )

        if project_area_idx < 0:
            raise QgsProcessingException(
                f"Projectgebied-kolom '{project_area_field}' "
                "bestaat niet in de invoerlaag."
            )

        input_layer = self._source_to_project_layer(
            source.sourceName()
        )

        input_crs = (
            input_layer.crs()
            if input_layer is not None
            else source.sourceCrs()
        )

        if (
            selected_only
            and input_layer is not None
        ):

            features = list(
                input_layer.selectedFeatures()
            )

            if not features:

                feedback.pushInfo(
                    "Geen geselecteerde polygonen gevonden; "
                    "alle polygonen uit de invoerlaag worden gebruikt."
                )

                features = list(
                    source.getFeatures()
                )

        else:

            if (
                selected_only
                and input_layer is None
            ):

                feedback.pushInfo(
                    "Invoer is geen actieve projectlaag; "
                    "selectie kan niet worden gelezen. "
                    "Alle polygonen uit de invoerlaag worden gebruikt."
                )

            features = list(
                source.getFeatures()
            )

        if not features:
            raise QgsProcessingException(
                "De invoerlaag bevat geen polygonen."
            )

        transform = None

        if input_crs != self.TARGET_CRS:

            transform = QgsCoordinateTransform(
                input_crs,
                self.TARGET_CRS,
                QgsProject.instance(),
            )

        polygon_records = []

        for feat in features:

            if not feat.hasGeometry():
                continue

            geom = QgsGeometry(
                feat.geometry()
            )

            if (
                geom is None
                or geom.isEmpty()
            ):
                continue

            if transform is not None:
                geom.transform(transform)

            if not geom.isGeosValid():

                fixed = geom.makeValid()

                if (
                    fixed
                    and not fixed.isEmpty()
                ):
                    geom = fixed

            if (
                geom is None
                or geom.isEmpty()
            ):
                continue

            project_value = (
                self._clean_attribute_value(
                    feat[project_idx],
                    "Onbekend project",
                )
            )

            project_area_value = (
                self._clean_attribute_value(
                    feat[project_area_idx],
                    "Onbekend projectgebied",
                )
            )

            polygon_records.append(
                {
                    "geometry": geom,
                    "project": project_value,
                    "projectgebied":
                        project_area_value,
                }
            )

        if not polygon_records:
            raise QgsProcessingException(
                "De invoerlaag bevat geen bruikbare polygonen."
            )

        chosen = [
            self.LAYER_OPTIONS[i]
            for i in layer_indices
        ]

        total_polygons = len(
            polygon_records
        )

        total_steps = (
            len(chosen)
            * total_polygons
        )

        completed_steps = 0

        created_layers = []

        output_gpkg = (
            self._normalize_optional_gpkg_path(
                output_gpkg
            )
        )

        if output_gpkg:

            output_gpkg = os.path.abspath(
                output_gpkg
            )

        else:

            output_gpkg = os.path.join(
                tempfile.gettempdir(),
                (
                    "pdok_selectie_groot_v6_"
                    f"{int(time.time() * 1000)}"
                    ".gpkg"
                ),
            )

        if os.path.exists(output_gpkg):
            os.remove(output_gpkg)

        mode_text = (
            "Project"
            if merge_by_project
            else "Projectgebied"
        )

        feedback.pushInfo(
            f"Tussentijdse opslag: {output_gpkg}"
        )

        feedback.pushInfo(
            f"Aantal polygonen: {total_polygons}"
        )

        feedback.pushInfo(
            f"Resultaatgroepering: per {mode_text}"
        )

        feedback.pushInfo(
            "Opslagmodus: iedere PDOK-batch "
            f"van maximaal {self.PAGE_LIMIT} objecten "
            "wordt direct aan de juiste "
            "GeoPackage-laag toegevoegd."
        )

        gpkg_layer_exists = {}

        for (
            label,
            key,
            service_type,
            target,
        ) in chosen:

            if feedback.isCanceled():
                break

            feedback.pushInfo(
                f"Start PDOK-laag: {label}"
            )

            for (
                polygon_index,
                record,
            ) in enumerate(
                polygon_records,
                start=1,
            ):

                if feedback.isCanceled():
                    break

                selection_geom = record[
                    "geometry"
                ]

                project_value = record[
                    "project"
                ]

                project_area_value = record[
                    "projectgebied"
                ]

                group_value = (
                    project_value
                    if merge_by_project
                    else project_area_value
                )

                output_layer_name = (
                    self._build_output_layer_name(
                        group_value=group_value,
                        layer_key=key,
                        layer_label=label,
                    )
                )

                layer_already_exists = (
                    gpkg_layer_exists.get(
                        output_layer_name,
                        False,
                    )
                )

                bbox = (
                    selection_geom.boundingBox()
                )

                feedback.pushInfo(
                    f"{label} - polygoon "
                    f"{polygon_index}/{total_polygons} "
                    f"[Project: {project_value} | "
                    f"Projectgebied: {project_area_value}] "
                    f"-> {output_layer_name}"
                )

                if (
                    service_type
                    in self.OGC_BASES
                ):

                    (
                        received_count,
                        written_count,
                        layer_exists_after,
                    ) = (
                        self._stream_ogcapi_collection(
                            service_type=
                                service_type,
                            collection=
                                target,
                            bbox=
                                bbox,
                            selection_geom=
                                selection_geom,
                            exact_clip=
                                exact_clip,
                            gpkg_path=
                                output_gpkg,
                            layer_name=
                                output_layer_name,
                            layer_already_exists=
                                layer_already_exists,
                            feedback=
                                feedback,
                            polygon_index=
                                polygon_index,
                            project_value=
                                project_value,
                            project_area_value=
                                project_area_value,
                        )
                    )

                else:

                    (
                        received_count,
                        written_count,
                        layer_exists_after,
                    ) = (
                        self._stream_wfs_layer(
                            typename=
                                target,
                            bbox=
                                bbox,
                            selection_geom=
                                selection_geom,
                            exact_clip=
                                exact_clip,
                            gpkg_path=
                                output_gpkg,
                            layer_name=
                                output_layer_name,
                            layer_already_exists=
                                layer_already_exists,
                            feedback=
                                feedback,
                            polygon_index=
                                polygon_index,
                            project_value=
                                project_value,
                            project_area_value=
                                project_area_value,
                        )
                    )

                if layer_exists_after:

                    gpkg_layer_exists[
                        output_layer_name
                    ] = True

                feedback.pushInfo(
                    f"Polygoon "
                    f"{polygon_index}/{total_polygons} "
                    "afgerond: "
                    f"{received_count} ontvangen, "
                    f"{written_count} opgeslagen in "
                    f"'{output_layer_name}'."
                )

                completed_steps += 1

                feedback.setProgress(
                    int(
                        (
                            completed_steps
                            / total_steps
                        )
                        * 100
                    )
                )

        for layer_name in gpkg_layer_exists:

            if not gpkg_layer_exists[
                layer_name
            ]:
                continue

            result_uri = (
                f"{output_gpkg}"
                f"|layername={layer_name}"
            )

            result_layer = QgsVectorLayer(
                result_uri,
                layer_name,
                "ogr",
            )

            if result_layer.isValid():

                QgsProject.instance().addMapLayer(
                    result_layer
                )

                created_layers.append(
                    result_layer.name()
                )

                feedback.pushInfo(
                    f"Toegevoegd: "
                    f"{result_layer.name()} "
                    f"({result_layer.featureCount()} "
                    "objecten)"
                )

            else:

                feedback.reportError(
                    "GeoPackage-laag is opgeslagen "
                    "maar kon niet automatisch "
                    "worden geladen: "
                    f"{layer_name}"
                )

        feedback.setProgress(100)

        return {
            "AANTAL_LAGEN":
                len(created_layers),
            "LAGEN":
                ", ".join(created_layers),
            "GEOPACKAGE":
                output_gpkg,
        }

    def _clean_attribute_value(
        self,
        value,
        fallback,
    ):

        if (
            value is None
            or value == NULL
        ):
            return fallback

        cleaned = str(
            value
        ).strip()

        if (
            not cleaned
            or cleaned.upper()
            in (
                "NULL",
                "NONE",
            )
        ):
            return fallback

        return cleaned

    def _sanitize_layer_name_part(
        self,
        value,
    ):

        value = str(
            value
        ).strip()

        for character in (
            "|",
            "\n",
            "\r",
            "\t",
        ):

            value = value.replace(
                character,
                " ",
            )

        value = " ".join(
            value.split()
        )

        return (
            value
            or "Onbekend"
        )

    def _build_output_layer_name(
        self,
        group_value,
        layer_key,
        layer_label,
    ):

        suffixes = {
            "bag_pand":
                "BAG Panden",

            "bag_verblijfsobject":
                "BAG Verblijfsobjecten",

            "bag_adres":
                "BAG Adressen",

            "bag_ligplaats":
                "BAG Ligplaatsen",

            "bag_standplaats":
                "BAG Standplaatsen",

            "bag_woonplaats":
                "BAG Woonplaatsen",

            "brk_perceel":
                "BRK Percelen",

            "bgt_wegdeel":
                "BGT Wegdelen",

            "bgt_ondersteunendwegdeel":
                "BGT Ondersteunende wegdelen",

            "bgt_waterdeel":
                "BGT Waterdelen",

            "bgt_ondersteunendwaterdeel":
                "BGT Ondersteunende waterdelen",
        }

        clean_group = (
            self._sanitize_layer_name_part(
                group_value
            )
        )

        suffix = suffixes.get(
            layer_key,
            layer_label.replace(
                " - ",
                " ",
            ),
        )

        return (
            f"{clean_group} {suffix}"
        )

    def _source_to_project_layer(
        self,
        source_name,
    ):

        for layer in (
            QgsProject.instance()
            .mapLayers()
            .values()
        ):

            if (
                layer.name()
                == source_name
                or layer.source()
                == source_name
            ):

                return layer

        matches = (
            QgsProject.instance()
            .mapLayersByName(
                source_name
            )
        )

        return (
            matches[0]
            if matches
            else None
        )

    def _stream_ogcapi_collection(
        self,
        service_type,
        collection,
        bbox,
        selection_geom,
        exact_clip,
        gpkg_path,
        layer_name,
        layer_already_exists,
        feedback,
        polygon_index,
        project_value,
        project_area_value,
    ):

        base_url = self.OGC_BASES[
            service_type
        ]

        url = (
            base_url.format(
                collection=collection
            )
            + "?"
            + urllib.parse.urlencode(
                {
                    "f":
                        "json",

                    "crs":
                        "http://www.opengis.net/"
                        "def/crs/EPSG/0/28992",

                    "bbox-crs":
                        "http://www.opengis.net/"
                        "def/crs/EPSG/0/28992",

                    "bbox":
                        f"{bbox.xMinimum()},"
                        f"{bbox.yMinimum()},"
                        f"{bbox.xMaximum()},"
                        f"{bbox.yMaximum()}",

                    "limit":
                        str(self.PAGE_LIMIT),
                }
            )
        )

        total_received = 0
        total_written = 0
        batch_number = 0

        while url:

            if feedback.isCanceled():
                break

            data = self._read_json_url(
                url
            )

            feats = data.get(
                "features",
                [],
            )

            batch_number += 1

            total_received += len(
                feats
            )

            if (
                total_received
                > self.MAX_FEATURES_PER_LAYER
            ):

                raise QgsProcessingException(
                    f"Te veel objecten voor "
                    f"{collection}. "
                    "Limiet is "
                    f"{self.MAX_FEATURES_PER_LAYER}. "
                    "Verklein de polygoon."
                )

            if feats:

                written = (
                    self._store_feature_batch(
                        features=
                            feats,

                        temp_name=
                            f"{collection}_"
                            f"p{polygon_index}_"
                            f"b{batch_number}",

                        output_name=
                            f"{collection} "
                            f"polygoon "
                            f"{polygon_index} "
                            f"batch "
                            f"{batch_number}",

                        selection_geom=
                            selection_geom,

                        exact_clip=
                            exact_clip,

                        gpkg_path=
                            gpkg_path,

                        layer_name=
                            layer_name,

                        layer_already_exists=
                            layer_already_exists,

                        feedback=
                            feedback,

                        project_value=
                            project_value,

                        project_area_value=
                            project_area_value,
                    )
                )

                if written > 0:

                    layer_already_exists = True

                    total_written += written

                feedback.pushInfo(
                    f"{collection} - "
                    f"polygoon "
                    f"{polygon_index}, "
                    f"batch "
                    f"{batch_number}: "
                    f"{len(feats)} ontvangen, "
                    f"{written} direct "
                    "opgeslagen "
                    f"(ontvangen totaal "
                    f"{total_received})."
                )

            next_url = None

            for link in data.get(
                "links",
                [],
            ):

                if (
                    link.get("rel")
                    == "next"
                    and link.get("href")
                ):

                    next_url = link[
                        "href"
                    ]

                    break

            url = next_url

        return (
            total_received,
            total_written,
            layer_already_exists,
        )

    def _stream_wfs_layer(
        self,
        typename,
        bbox,
        selection_geom,
        exact_clip,
        gpkg_path,
        layer_name,
        layer_already_exists,
        feedback,
        polygon_index,
        project_value,
        project_area_value,
    ):

        total_received = 0
        total_written = 0
        start_index = 0
        batch_number = 0

        while True:

            if feedback.isCanceled():
                break

            params = {
                "service":
                    "WFS",

                "version":
                    "2.0.0",

                "request":
                    "GetFeature",

                "typeNames":
                    typename,

                "srsName":
                    "EPSG:28992",

                "bbox":
                    f"{bbox.xMinimum()},"
                    f"{bbox.yMinimum()},"
                    f"{bbox.xMaximum()},"
                    f"{bbox.yMaximum()},"
                    "EPSG:28992",

                "outputFormat":
                    "json",

                "count":
                    str(self.PAGE_LIMIT),

                "startIndex":
                    str(start_index),
            }

            url = (
                self.BRK_WFS
                + "?"
                + urllib.parse.urlencode(
                    params
                )
            )

            data = self._read_json_url(
                url
            )

            feats = data.get(
                "features",
                [],
            )

            batch_number += 1

            total_received += len(
                feats
            )

            if (
                total_received
                > self.MAX_FEATURES_PER_LAYER
            ):

                raise QgsProcessingException(
                    "Te veel percelen ontvangen. "
                    "Limiet is "
                    f"{self.MAX_FEATURES_PER_LAYER}. "
                    "Verklein de polygoon."
                )

            if feats:

                safe_name = typename.replace(
                    ":",
                    "_",
                )

                written = (
                    self._store_feature_batch(
                        features=
                            feats,

                        temp_name=
                            f"{safe_name}_"
                            f"p{polygon_index}_"
                            f"b{batch_number}",

                        output_name=
                            f"{safe_name} "
                            f"polygoon "
                            f"{polygon_index} "
                            f"batch "
                            f"{batch_number}",

                        selection_geom=
                            selection_geom,

                        exact_clip=
                            exact_clip,

                        gpkg_path=
                            gpkg_path,

                        layer_name=
                            layer_name,

                        layer_already_exists=
                            layer_already_exists,

                        feedback=
                            feedback,

                        project_value=
                            project_value,

                        project_area_value=
                            project_area_value,
                    )
                )

                if written > 0:

                    layer_already_exists = True

                    total_written += written

                feedback.pushInfo(
                    f"{typename} - "
                    f"polygoon "
                    f"{polygon_index}, "
                    f"batch "
                    f"{batch_number}: "
                    f"{len(feats)} ontvangen, "
                    f"{written} direct "
                    "opgeslagen "
                    f"(ontvangen totaal "
                    f"{total_received})."
                )

            if (
                len(feats)
                < self.PAGE_LIMIT
            ):
                break

            start_index += (
                self.PAGE_LIMIT
            )

        return (
            total_received,
            total_written,
            layer_already_exists,
        )

    def _store_feature_batch(
        self,
        features,
        temp_name,
        output_name,
        selection_geom,
        exact_clip,
        gpkg_path,
        layer_name,
        layer_already_exists,
        feedback,
        project_value,
        project_area_value,
    ):

        if not features:
            return 0

        geojson_path = (
            self._write_geojson_temp(
                {
                    "type":
                        "FeatureCollection",
                    "features":
                        features,
                },
                temp_name,
            )
        )

        try:

            src_layer = QgsVectorLayer(
                geojson_path,
                output_name + " bron",
                "ogr",
            )

            if not src_layer.isValid():

                raise QgsProcessingException(
                    "Kon tijdelijke "
                    "PDOK-batch niet als "
                    "vectorlaag laden: "
                    f"{output_name}"
                )

            result_layer = (
                self._filter_to_memory_layer(
                    src_layer=
                        src_layer,

                    output_name=
                        output_name,

                    selection_geom=
                        selection_geom,

                    exact_clip=
                        exact_clip,

                    feedback=
                        feedback,

                    project_value=
                        project_value,

                    project_area_value=
                        project_area_value,
                )
            )

            feature_count = (
                result_layer.featureCount()
            )

            if feature_count > 0:

                self._write_or_append_layer_to_gpkg(
                    layer=
                        result_layer,

                    gpkg_path=
                        gpkg_path,

                    layer_name=
                        layer_name,

                    layer_already_exists=
                        layer_already_exists,

                    feedback=
                        feedback,
                )

            return feature_count

        finally:

            try:

                if os.path.exists(
                    geojson_path
                ):

                    os.remove(
                        geojson_path
                    )

            except Exception:
                pass

    def _read_json_url(
        self,
        url,
    ):

        max_attempts = 6

        retry_delays = [
            2,
            4,
            8,
            16,
            30,
        ]

        for attempt in range(
            1,
            max_attempts + 1,
        ):

            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent":
                        "QGIS PDOK selectie "
                        "importeren groot V6"
                },
            )

            try:

                with urllib.request.urlopen(
                    req,
                    timeout=120,
                ) as response:

                    raw = (
                        response
                        .read()
                        .decode("utf-8")
                    )

                    return json.loads(
                        raw
                    )

            except urllib.error.HTTPError as exc:

                retryable = (
                    exc.code
                    in (
                        408,
                        429,
                        500,
                        502,
                        503,
                        504,
                    )
                )

                if (
                    not retryable
                    or attempt >= max_attempts
                ):

                    raise QgsProcessingException(
                        "PDOK request mislukt "
                        f"na {attempt} poging(en): "
                        f"HTTP {exc.code} "
                        f"{exc.reason}\n"
                        f"URL: {url}"
                    )

                delay = retry_delays[
                    attempt - 1
                ]

                time.sleep(delay)

            except (
                urllib.error.URLError,
                TimeoutError,
                ConnectionError,
            ) as exc:

                if attempt >= max_attempts:

                    raise QgsProcessingException(
                        "PDOK request mislukt "
                        f"na {attempt} poging(en): "
                        f"{exc}\n"
                        f"URL: {url}"
                    )

                delay = retry_delays[
                    attempt - 1
                ]

                time.sleep(delay)

            except json.JSONDecodeError as exc:

                if attempt >= max_attempts:

                    raise QgsProcessingException(
                        "PDOK gaf na "
                        f"{attempt} poging(en) "
                        "geen geldige JSON terug: "
                        f"{exc}\n"
                        f"URL: {url}"
                    )

                delay = retry_delays[
                    attempt - 1
                ]

                time.sleep(delay)

            except Exception as exc:

                raise QgsProcessingException(
                    "PDOK request mislukt: "
                    f"{exc}\n"
                    f"URL: {url}"
                )

        raise QgsProcessingException(
            "PDOK request definitief "
            "mislukt.\n"
            f"URL: {url}"
        )

    def _write_geojson_temp(
        self,
        data,
        name,
    ):

        path = os.path.join(
            tempfile.gettempdir(),
            (
                f"pdok_{name}_"
                f"{int(time.time() * 1000)}"
                ".geojson"
            ),
        )

        with open(
            path,
            "w",
            encoding="utf-8",
        ) as handle:

            json.dump(
                data,
                handle,
                ensure_ascii=False,
            )

        return path

    def _filter_to_memory_layer(
        self,
        src_layer,
        output_name,
        selection_geom,
        exact_clip,
        feedback,
        project_value="",
        project_area_value="",
    ):

        geom_type = (
            QgsWkbTypes.displayString(
                src_layer.wkbType()
            )
        )

        if (
            geom_type.lower()
            == "unknown"
        ):
            geom_type = "Geometry"

        mem_layer = QgsVectorLayer(
            (
                f"{geom_type}"
                "?crs=EPSG:28992"
            ),
            output_name,
            "memory",
        )

        provider = (
            mem_layer.dataProvider()
        )

        provider.addAttributes(
            src_layer.fields()
        )

        provider.addAttributes(
            [
                QgsField(
                    "bron_project",
                    QVariant.String,
                ),
                QgsField(
                    "bron_projectgebied",
                    QVariant.String,
                ),
            ]
        )

        mem_layer.updateFields()

        request = (
            QgsFeatureRequest()
            .setFilterRect(
                selection_geom
                .boundingBox()
            )
        )

        new_features = []

        for feat in (
            src_layer.getFeatures(
                request
            )
        ):

            if feedback.isCanceled():
                break

            if not feat.hasGeometry():
                continue

            geom = feat.geometry()

            if (
                geom is None
                or geom.isEmpty()
            ):
                continue

            if not geom.intersects(
                selection_geom
            ):
                continue

            out_geom = geom

            if exact_clip:

                out_geom = (
                    geom.intersection(
                        selection_geom
                    )
                )

                if (
                    out_geom is None
                    or out_geom.isEmpty()
                ):
                    continue

                if not out_geom.isGeosValid():

                    fixed = (
                        out_geom.makeValid()
                    )

                    if (
                        fixed
                        and not fixed.isEmpty()
                    ):
                        out_geom = fixed

            out_feat = QgsFeature(
                mem_layer.fields()
            )

            out_feat.setAttributes(
                feat.attributes()
                + [
                    project_value,
                    project_area_value,
                ]
            )

            out_feat.setGeometry(
                out_geom
            )

            new_features.append(
                out_feat
            )

        provider.addFeatures(
            new_features
        )

        mem_layer.updateExtents()

        return mem_layer

    def _normalize_optional_gpkg_path(
        self,
        output_gpkg,
    ):

        if output_gpkg is None:
            return ""

        value = str(
            output_gpkg
        ).strip()

        if not value:
            return ""

        if (
            value.upper()
            == "TEMPORARY_OUTPUT"
        ):
            return ""

        if not value.lower().endswith(
            ".gpkg"
        ):
            value = f"{value}.gpkg"

        return value

    def _write_or_append_layer_to_gpkg(
        self,
        layer,
        gpkg_path,
        layer_name,
        layer_already_exists,
        feedback,
    ):

        options = (
            QgsVectorFileWriter
            .SaveVectorOptions()
        )

        options.driverName = "GPKG"

        options.layerName = (
            layer_name
        )

        options.fileEncoding = (
            "UTF-8"
        )

        if layer_already_exists:

            options.actionOnExistingFile = (
                QgsVectorFileWriter
                .AppendToLayerNoNewFields
            )

        elif os.path.exists(
            gpkg_path
        ):

            options.actionOnExistingFile = (
                QgsVectorFileWriter
                .CreateOrOverwriteLayer
            )

        else:

            options.actionOnExistingFile = (
                QgsVectorFileWriter
                .CreateOrOverwriteFile
            )

        writer_result = (
            QgsVectorFileWriter
            .writeAsVectorFormatV3(
                layer,
                gpkg_path,
                QgsProject.instance()
                .transformContext(),
                options,
            )
        )

        result_code = (
            writer_result[0]
            if isinstance(
                writer_result,
                tuple,
            )
            else writer_result
        )

        error_message = ""

        if (
            isinstance(
                writer_result,
                tuple,
            )
            and len(
                writer_result
            ) > 1
        ):

            error_message = str(
                writer_result[1]
            )

        if (
            result_code
            != QgsVectorFileWriter.NoError
        ):

            raise QgsProcessingException(
                "GeoPackage schrijven/"
                "toevoegen mislukt voor "
                f"{layer_name}: "
                f"{error_message or writer_result}"
            )

    def _write_layer_to_gpkg(
        self,
        layer,
        gpkg_path,
        layer_name,
        feedback,
    ):

        options = (
            QgsVectorFileWriter
            .SaveVectorOptions()
        )

        options.driverName = "GPKG"

        options.layerName = (
            layer_name
        )

        options.fileEncoding = (
            "UTF-8"
        )

        options.actionOnExistingFile = (
            QgsVectorFileWriter
            .CreateOrOverwriteFile
            if not os.path.exists(
                gpkg_path
            )
            else QgsVectorFileWriter
            .CreateOrOverwriteLayer
        )

        writer_result = (
            QgsVectorFileWriter
            .writeAsVectorFormatV3(
                layer,
                gpkg_path,
                QgsProject.instance()
                .transformContext(),
                options,
            )
        )

        result_code = (
            writer_result[0]
            if isinstance(
                writer_result,
                tuple,
            )
            else writer_result
        )

        error_message = ""

        if (
            isinstance(
                writer_result,
                tuple,
            )
            and len(
                writer_result
            ) > 1
        ):

            error_message = str(
                writer_result[1]
            )

        if (
            result_code
            != QgsVectorFileWriter.NoError
        ):

            feedback.reportError(
                "GeoPackage schrijven "
                "mislukt voor "
                f"{layer.name()}: "
                f"{error_message or writer_result}"
            )