# -*- coding: utf-8 -*-
from qgis.core import QgsProcessingProvider
from .pdok_selectie_importeren_algorithm import PdokSelectieImporterenAlgorithm

class PdokSelectieImporterenProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        self.addAlgorithm(PdokSelectieImporterenAlgorithm())

    def id(self):
        return "pdok_selectie_importeren"

    def name(self):
        return "PDOK Selectie Importeren"

    def longName(self):
        return self.name()
