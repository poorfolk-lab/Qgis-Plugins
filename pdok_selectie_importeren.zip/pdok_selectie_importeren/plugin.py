# -*- coding: utf-8 -*-
from .provider import PdokSelectieImporterenProvider

class PdokSelectieImporterenPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initGui(self):
        from qgis.core import QgsApplication
        self.provider = PdokSelectieImporterenProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        from qgis.core import QgsApplication
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
