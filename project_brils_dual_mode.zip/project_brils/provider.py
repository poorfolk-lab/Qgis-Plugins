from qgis.core import QgsProcessingProvider
from .route_excel_xy_direct_algorithm import RouteObjectenNaarExcelXYDirectAlgorithm

class ProjectBrilsProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        self.addAlgorithm(RouteObjectenNaarExcelXYDirectAlgorithm())

    def id(self): return "project_brils"
    def name(self): return "Project Brils"
    def longName(self): return "Project Brils"
