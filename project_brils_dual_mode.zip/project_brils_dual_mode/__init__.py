def classFactory(iface):
    from .plugin import ProjectBrilsPlugin
    return ProjectBrilsPlugin(iface)
