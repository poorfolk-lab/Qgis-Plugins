from qgis.core import (
    QgsFeature, QgsField, QgsFields, QgsGeometry, QgsPointXY, QgsProcessing,
    QgsProcessingAlgorithm, QgsProcessingException, QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource, QgsProcessingParameterField,
    QgsProcessingParameterFile, QgsProcessingParameterString, QgsProcessingParameterBoolean, QgsSpatialIndex,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QVariant
import re
import math
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path


class RouteObjectenNaarExcelXYDirectAlgorithm(QgsProcessingAlgorithm):
    POLYGONS = "POLYGONS"
    ADDRESS_POINTS = "ADDRESS_POINTS"
    EXCEL_FILE = "EXCEL_FILE"

    POINT_POSTCODE_FIELD = "POINT_POSTCODE_FIELD"
    POINT_HOUSE_FIELD = "POINT_HOUSE_FIELD"
    POINT_ADDITION_FIELD = "POINT_ADDITION_FIELD"
    POINT_HOUSELETTER_FIELD = "POINT_HOUSELETTER_FIELD"
    POINT_ROOM_FIELD = "POINT_ROOM_FIELD"

    EXCEL_LABEL_FIELD = "EXCEL_LABEL_FIELD"
    USE_EXCEL_LABEL = "USE_EXCEL_LABEL"
    EXCEL_POSTCODE_FIELD = "EXCEL_POSTCODE_FIELD"
    EXCEL_HOUSE_FIELD = "EXCEL_HOUSE_FIELD"
    EXCEL_ADDITION_FIELD = "EXCEL_ADDITION_FIELD"
    EXCEL_ROOM_FIELD = "EXCEL_ROOM_FIELD"
    EXCEL_X_FIELD = "EXCEL_X_FIELD"
    EXCEL_Y_FIELD = "EXCEL_Y_FIELD"

    OUTPUT = "OUTPUT"
    POINTS_OUTPUT = "POINTS_OUTPUT"

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.POLYGONS, "Objecten / polygonen (pand of perceel)", [QgsProcessing.TypeVectorPolygon]))
        self.addParameter(QgsProcessingParameterFeatureSource(self.ADDRESS_POINTS, "Adrespuntenlaag", [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterFile(self.EXCEL_FILE, "Excelbestand met X/Y", behavior=QgsProcessingParameterFile.File, extension="xlsx"))
        self.addParameter(QgsProcessingParameterField(self.POINT_POSTCODE_FIELD, "Postcodeveld adrespunt", parentLayerParameterName=self.ADDRESS_POINTS, defaultValue="postcode"))
        self.addParameter(QgsProcessingParameterField(self.POINT_HOUSE_FIELD, "Huisnummerveld adrespunt", parentLayerParameterName=self.ADDRESS_POINTS, defaultValue="huisnummer"))
        self.addParameter(QgsProcessingParameterField(self.POINT_ADDITION_FIELD, "Toevoegingveld adrespunt", parentLayerParameterName=self.ADDRESS_POINTS, defaultValue="toevoeging", optional=True))
        self.addParameter(QgsProcessingParameterField(self.POINT_HOUSELETTER_FIELD, "Huisletterveld adrespunt", parentLayerParameterName=self.ADDRESS_POINTS, defaultValue="huisletter", optional=True))
        self.addParameter(QgsProcessingParameterField(self.POINT_ROOM_FIELD, "Kamerveld adrespunt", parentLayerParameterName=self.ADDRESS_POINTS, defaultValue="kamer", optional=True))
        self.addParameter(QgsProcessingParameterBoolean(self.USE_EXCEL_LABEL, "Vergelijken via Excel-label", defaultValue=True))
        self.addParameter(QgsProcessingParameterString(self.EXCEL_LABEL_FIELD, "Labelkolom Excel (bij labelmodus)", defaultValue="Label"))
        self.addParameter(QgsProcessingParameterString(self.EXCEL_POSTCODE_FIELD, "Postcodekolom Excel (zonder label)", defaultValue="Postcode"))
        self.addParameter(QgsProcessingParameterString(self.EXCEL_HOUSE_FIELD, "Huisnummerkolom Excel (zonder label)", defaultValue="Huisnummer"))
        self.addParameter(QgsProcessingParameterString(self.EXCEL_ADDITION_FIELD, "Toevoegingkolom Excel (zonder label)", defaultValue="Toevoeging"))
        self.addParameter(QgsProcessingParameterString(self.EXCEL_ROOM_FIELD, "Kamerkolom Excel (zonder label)", defaultValue="Kamer"))
        self.addParameter(QgsProcessingParameterString(self.EXCEL_X_FIELD, "X-kolom Excel", defaultValue="X"))
        self.addParameter(QgsProcessingParameterString(self.EXCEL_Y_FIELD, "Y-kolom Excel", defaultValue="Y"))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, "Brils Directe Lijnen Excel XY", QgsProcessing.TypeVectorLine))
        self.addParameter(QgsProcessingParameterFeatureSink(self.POINTS_OUTPUT, "Brils Directe Routepunten Excel XY", QgsProcessing.TypeVectorPoint))

    def processAlgorithm(self, parameters, context, feedback):
        polygons = self.parameterAsSource(parameters, self.POLYGONS, context)
        address_points = self.parameterAsSource(parameters, self.ADDRESS_POINTS, context)
        excel_path = self.parameterAsFile(parameters, self.EXCEL_FILE, context)
        if polygons is None or address_points is None:
            raise QgsProcessingException("Objectenlaag of adrespuntenlaag kon niet worden gelezen.")
        if polygons.sourceCrs() != address_points.sourceCrs():
            raise QgsProcessingException("Objectenlaag en adrespuntenlaag moeten hetzelfde CRS hebben.")

        pp = self.parameterAsString(parameters, self.POINT_POSTCODE_FIELD, context)
        ph = self.parameterAsString(parameters, self.POINT_HOUSE_FIELD, context)
        pa = self.parameterAsString(parameters, self.POINT_ADDITION_FIELD, context)
        pl = self.parameterAsString(parameters, self.POINT_HOUSELETTER_FIELD, context)
        pr = self.parameterAsString(parameters, self.POINT_ROOM_FIELD, context)
        use_label = self.parameterAsBoolean(parameters, self.USE_EXCEL_LABEL, context)
        el = self.parameterAsString(parameters, self.EXCEL_LABEL_FIELD, context)
        ep = self.parameterAsString(parameters, self.EXCEL_POSTCODE_FIELD, context)
        eh = self.parameterAsString(parameters, self.EXCEL_HOUSE_FIELD, context)
        ea = self.parameterAsString(parameters, self.EXCEL_ADDITION_FIELD, context)
        er = self.parameterAsString(parameters, self.EXCEL_ROOM_FIELD, context)
        ex = self.parameterAsString(parameters, self.EXCEL_X_FIELD, context)
        ey = self.parameterAsString(parameters, self.EXCEL_Y_FIELD, context)

        rows = self._read_xlsx_rows(excel_path)
        excel_lookup, duplicate_excel_keys, extra_cols = self._build_excel_lookup(rows, use_label, el, ep, eh, ea, er, ex, ey)
        feedback.pushInfo(f"Excelregels voor uitvoer: {len(rows)}")
        feedback.pushInfo(f"Unieke Excel-adressleutels: {len(excel_lookup)}")
        feedback.pushInfo(f"Dubbele Excel matches: {len(duplicate_excel_keys)}")

        poly_index = QgsSpatialIndex(); poly_data = {}; invalid = 0
        for pf in polygons.getFeatures():
            g = pf.geometry()
            if g is None or g.isEmpty(): invalid += 1; continue
            try:
                if hasattr(g, 'isGeosValid') and not g.isGeosValid(): invalid += 1; continue
            except Exception: invalid += 1; continue
            poly_data[int(pf.id())] = {"feature": pf, "geometry": g}; poly_index.addFeature(pf)
        if invalid: feedback.pushInfo(f"Ongeldige/lege polygonen overgeslagen: {invalid}.")
        if not poly_data: raise QgsProcessingException("Geen geldige objectpolygonen gevonden.")

        fields = QgsFields()
        for n in ["excel_row","match_key","label","match_type","bag_aantal","postcode","huisnr","extra","toevoeging","huisletter","kamer","excel_x","excel_y","lengte_m","status","object_id","adres_id"]:
            typ = QVariant.Int if n in ("excel_row","bag_aantal") else QVariant.Double if n in ("excel_x","excel_y","lengte_m") else QVariant.String
            fields.append(QgsField(n, typ))
        existing={f.name().lower() for f in fields}; extra_field_names={}
        for col in extra_cols:
            safe=self._safe_field_name(col, existing); existing.add(safe.lower()); extra_field_names[col]=safe; fields.append(QgsField(safe, QVariant.String))
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.LineString, polygons.sourceCrs())
        pflds=QgsFields()
        for n in ["match_key","label","punt_type","postcode","huisnr","extra","object_id"]: pflds.append(QgsField(n,QVariant.String))
        psink, pdest = self.parameterAsSink(parameters, self.POINTS_OUTPUT, context, pflds, QgsWkbTypes.Point, polygons.sourceCrs())
        def add_pt(mk, typ, pc, hn, extra, oid, pt):
            f=QgsFeature(pflds); f['match_key']=mk; f['label']=mk; f['punt_type']=typ; f['postcode']=pc; f['huisnr']=hn; f['extra']=extra; f['object_id']=str(oid) if oid is not None else ''; f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(pt))); psink.addFeature(f)

        bag_lookup={}; bag_counts={}; alternate_lookup={}; alternate_counts={}; total_bag=address_points.featureCount() or 1
        for idx, af in enumerate(address_points.getFeatures()):
            if feedback.isCanceled(): break
            feedback.setProgress(int((idx/total_bag)*50))
            pc=self._clean_token(self._safe_attr(af,pp)); hn=self._clean_number_token(self._safe_attr(af,ph))
            add=self._clean_token(self._safe_attr(af,pa)); hl=self._clean_token(self._safe_attr(af,pl)); room=self._clean_token(self._safe_attr(af,pr))
            extra=self._clean_token(f"{add}{hl}{room}"); mk=self._make_match_key(pc,hn,extra)
            alternate_extra=self._clean_token(f"{hl}{add}{room}"); alternate_mk=self._make_match_key(pc,hn,alternate_extra)
            if mk not in excel_lookup and (alternate_mk==mk or alternate_mk not in excel_lookup): continue
            candidate={'feature':QgsFeature(af),'postcode':pc,'huisnr':hn,'toevoeging':add,'huisletter':hl,'kamer':room}
            if mk in excel_lookup:
                bag_counts[mk]=bag_counts.get(mk,0)+1
                if mk not in bag_lookup or af.id()<bag_lookup[mk]['feature'].id(): bag_lookup[mk]={**candidate,'extra':extra}
            if alternate_mk!=mk and alternate_mk in excel_lookup:
                alternate_counts[alternate_mk]=alternate_counts.get(alternate_mk,0)+1
                if alternate_mk not in alternate_lookup or af.id()<alternate_lookup[alternate_mk]['feature'].id(): alternate_lookup[alternate_mk]={**candidate,'extra':alternate_extra}
        feedback.pushInfo(f"Excel-sleutels gevonden in BAG met bestaande volgorde: {len(bag_lookup)}; met huisletter eerst: {len(alternate_lookup)}")

        ok=failed=fallback_ok=duplicates_selected=0; total_excel=len(rows) or 1
        for idx, row in enumerate(rows):
            if feedback.isCanceled(): break
            feedback.setProgress(50+int((idx/total_excel)*50))
            mk=self._excel_match_key(row,use_label,el,ep,eh,ea,er)
            target=bag_lookup.get(mk)
            match_type='HUIDIGE_VOLGORDE' if target is not None else ''
            if target is None and mk in alternate_lookup:
                target=alternate_lookup[mk]; match_type='HUISLETTER_EERST'
            feat=QgsFeature(fields); feat['excel_row']=row.get('__excel_row__',idx+2); feat['match_key']=mk; feat['label']=mk
            feat['match_type']=match_type
            for original, safe in extra_field_names.items(): feat[safe]=self._string_value(row.get(original,''))
            if target:
                for output,source in [('postcode','postcode'),('huisnr','huisnr'),('extra','extra'),('toevoeging','toevoeging'),('huisletter','huisletter'),('kamer','kamer')]: feat[output]=target[source]
                af=target['feature']; feat['adres_id']=str(af.id())
                feat['bag_aantal']=(bag_counts if match_type=='HUIDIGE_VOLGORDE' else alternate_counts)[mk]
            if not mk: feat['status']='FAILED_EMPTY_EXCEL_ADDRESS'; sink.addFeature(feat); failed+=1; continue
            if mk in duplicate_excel_keys: feat['status']='FAILED_DUPLICATE_EXCEL_MATCH'; sink.addFeature(feat); failed+=1; continue
            if target is None: feat['status']='FAILED_NO_ADDRESS_MATCH'; sink.addFeature(feat); failed+=1; continue
            if feat['bag_aantal']>1: duplicates_selected+=1
            try: x=float(str(self._row_value(row,ex)).replace(',','.')); y=float(str(self._row_value(row,ey)).replace(',','.'))
            except (TypeError,ValueError): feat['status']='FAILED_INVALID_EXCEL_XY'; sink.addFeature(feat); failed+=1; continue
            if not (math.isfinite(x) and math.isfinite(y)): feat['status']='FAILED_INVALID_EXCEL_XY'; sink.addFeature(feat); failed+=1; continue
            tpt=QgsPointXY(x,y); feat['excel_x']=x; feat['excel_y']=y
            apt=self._feature_point(af.geometry())
            if apt is None: feat['status']='FAILED_INVALID_ADDRESS_POINT'; sink.addFeature(feat); failed+=1; continue
            oid=self._find_containing_polygon(apt, poly_index, poly_data)
            if oid is None: feat['status']='FAILED_NO_CONTAINING_OBJECT'; sink.addFeature(feat); failed+=1; continue
            line,objpt,leng=self._shortest_line_point_to_polygon(tpt, poly_data[oid]['geometry']); feat['object_id']=str(oid)
            if line is None: feat['status']='FAILED_NO_DIRECT_LINE'; sink.addFeature(feat); failed+=1; continue
            feat['lengte_m']=round(leng,3); feat['status']='OK_DIRECT'; feat.setGeometry(line); sink.addFeature(feat)
            add_pt(mk,'START_XY',target['postcode'],target['huisnr'],target['extra'],oid,tpt); add_pt(mk,'EIND_OBJECT',target['postcode'],target['huisnr'],target['extra'],oid,objpt); ok+=1
            if match_type=='HUISLETTER_EERST': fallback_ok+=1
        feedback.setProgress(100); feedback.pushInfo(f"Klaar. Excelregels verwerkt: {ok+failed}. OK: {ok}. FAILED: {failed}. Alternatieve volgorde OK: {fallback_ok}. Dubbele BAG-sleutels met laagste FID gekozen: {duplicates_selected}.")
        return {self.OUTPUT:dest_id, self.POINTS_OUTPUT:pdest}

    def _feature_point(self, geom):
        try:
            if geom is None or geom.isEmpty(): return None
            if geom.isMultipart():
                pts=geom.asMultiPoint(); return QgsPointXY(pts[0]) if pts else None
            return QgsPointXY(geom.asPoint())
        except Exception: return None
    def _shortest_line_point_to_polygon(self, point, poly_geom):
        try: line=QgsGeometry.fromPointXY(QgsPointXY(point)).shortestLine(poly_geom)
        except Exception: return None,None,None
        if line is None or line.isEmpty(): return None,None,None
        pts=line.asMultiPolyline()[0] if line.isMultipart() else line.asPolyline()
        return (line,QgsPointXY(pts[-1]),line.length()) if len(pts)>=2 else (None,None,None)
    def _find_containing_polygon(self, point, poly_index, poly_data):
        pg=QgsGeometry.fromPointXY(point); best=None; area=None
        for fid in poly_index.intersects(pg.boundingBox()):
            if fid not in poly_data: continue
            g=poly_data[fid]['geometry']
            try:
                if g.contains(pg) or g.intersects(pg):
                    a=g.area()
                    if best is None or a<area: best=fid; area=a
            except Exception: continue
        return best
    def _safe_attr(self, feature, field_name):
        if not field_name: return ''
        try: return feature[field_name]
        except Exception: return ''
    def _make_match_key(self, postcode, huisnr, extra): return f"{self._clean_token(postcode)}{self._clean_number_token(huisnr)}{self._clean_token(extra)}"
    def _clean_token(self, value):
        if value is None: return ''
        txt=str(value).strip()
        if txt.upper() in ('NULL','NONE','NAN'): return ''
        if txt.endswith('.0'): txt=txt[:-2]
        return re.sub(r'[^0-9A-Za-z]','',txt).upper()
    def _clean_number_token(self,value): return self._clean_token(value)
    def _row_value(self,row,column):
        key=next((k for k in row if str(k).strip().lower()==column.strip().lower()),None)
        return row.get(key) if key is not None else None
    def _excel_match_key(self,row,use_label,label_col,pc_col,hn_col,add_col,room_col):
        if use_label: return self._clean_token(self._row_value(row,label_col))
        pc=self._clean_token(self._row_value(row,pc_col)); hn=self._clean_number_token(self._row_value(row,hn_col))
        if not pc or not hn: return ''
        extra=self._clean_token(f"{self._clean_token(self._row_value(row,add_col)) if add_col else ''}{self._clean_token(self._row_value(row,room_col)) if room_col else ''}")
        return self._make_match_key(pc,hn,extra)
    def _string_value(self,value): return '' if value is None else str(value)
    def _safe_field_name(self,name,existing_lower):
        base=re.sub(r'[^0-9A-Za-z_]','_',str(name).strip()); base=re.sub(r'_+','_',base).strip('_') or 'excel_veld'
        if re.match(r'^[0-9]',base): base='x_'+base
        base=base[:10]; cand=base; i=1
        while cand.lower() in existing_lower:
            s=str(i); cand=base[:10-len(s)]+s; i+=1
        return cand
    def _build_excel_lookup(self, rows, use_label, label_col, pc_col, hn_col, add_col, room_col, x_col, y_col):
        lookup={}; dup=set()
        selected=(label_col,x_col,y_col) if use_label else (pc_col,hn_col,add_col,room_col,x_col,y_col)
        ignore={name.strip().lower() for name in selected if name}
        if not rows: raise QgsProcessingException('Excelbestand bevat geen gegevensrijen.')
        headers={str(k).strip().lower() for k in rows[0].keys()}
        required=(label_col,x_col,y_col) if use_label else (pc_col,hn_col,x_col,y_col)
        missing=[name for name in required if name.strip().lower() not in headers]
        if missing: raise QgsProcessingException(f"Excelkolom ontbreekt: {', '.join(missing)}")
        extra_cols=[]
        extra_cols=[c for c in rows[0].keys() if str(c).strip().lower() not in ignore and c!='__excel_row__']
        for row in rows:
            mk=self._excel_match_key(row,use_label,label_col,pc_col,hn_col,add_col,room_col)
            if not mk: continue
            if mk in lookup: dup.add(mk)
            lookup[mk]=True
        return lookup,dup,extra_cols
    def _read_xlsx_rows(self,path):
        ns={'main':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        def col_index(ref):
            letters=re.sub(r'[^A-Z]','',str(ref).upper()); idx=0
            for ch in letters: idx=idx*26+(ord(ch)-64)
            return idx-1
        def read_cell(cell, shared):
            typ=cell.attrib.get('t','')
            if typ=='inlineStr': return ''.join(t.text or '' for t in cell.findall('.//main:t',ns))
            v=cell.find('main:v',ns)
            if v is None: return ''
            raw=v.text or ''
            if typ=='s':
                try: return shared[int(raw)]
                except Exception: return ''
            return raw
        try:
            with zipfile.ZipFile(path,'r') as z:
                names=set(z.namelist()); shared=[]
                if 'xl/sharedStrings.xml' in names:
                    root=ET.fromstring(z.read('xl/sharedStrings.xml'))
                    for si in root.findall('main:si',ns): shared.append(''.join(t.text or '' for t in si.findall('.//main:t',ns)))
                wb=ET.fromstring(z.read('xl/workbook.xml')); sheet=wb.find('.//main:sheets/main:sheet', {'main':ns['main'],'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'})
                rid=sheet.attrib.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'); rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
                target=None
                for rel in rels:
                    if rel.attrib.get('Id')==rid: target=rel.attrib.get('Target'); break
                sp='xl/'+target.lstrip('/') if target else ''
                if sp not in names: sp='xl/worksheets/'+Path(target).name
                result=[]; headers=None
                with z.open(sp) as sheet_file:
                    events=ET.iterparse(sheet_file,events=('start','end'))
                    _,root=next(events)
                    for event,row in events:
                        if event!='end' or row.tag!=f"{{{ns['main']}}}row": continue
                        vals={}
                        for cell in row.findall('main:c',ns):
                            i=col_index(cell.attrib.get('r',''))
                            if i>=0: vals[i]=read_cell(cell,shared)
                        if headers is None:
                            maxc=max(vals,default=-1)+1
                            headers=[str(vals.get(i,'')).strip() for i in range(maxc)]
                        else:
                            item={'__excel_row__':int(row.attrib.get('r',len(result)+2))}
                            for i,h in enumerate(headers):
                                if h: item[h]=vals.get(i,'')
                            if any(str(v).strip() for k,v in item.items() if k!='__excel_row__'): result.append(item)
                        row.clear(); root.clear()
                return result
        except Exception as exc: raise QgsProcessingException(f'Excelbestand kon niet veilig worden gelezen: {exc}') from exc
    def name(self): return 'route_objecten_naar_excel_xy_direct'
    def displayName(self): return 'Route Objecten Naar Excel XY Direct'
    def group(self): return 'Routing'
    def groupId(self): return 'routing'
    def createInstance(self): return RouteObjectenNaarExcelXYDirectAlgorithm()
