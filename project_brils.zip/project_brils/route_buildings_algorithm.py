from qgis.core import (
    QgsFeature, QgsField, QgsFields, QgsGeometry, QgsPointXY, QgsProcessing,
    QgsProcessingAlgorithm, QgsProcessingException, QgsProcessingParameterBoolean,
    QgsProcessingParameterDistance, QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink, QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField, QgsProcessingParameterNumber, QgsSpatialIndex, QgsWkbTypes
)
from qgis.PyQt.QtCore import QVariant
from .common import (
    build_network, dist, feature_id_value, point_from_feature,
    polygon_boundary_start_point, route_between_points, find_nearest_segment
)
import heapq


class RouteBuildingsAlgorithm(QgsProcessingAlgorithm):
    POLYGONS = "POLYGONS"
    POINTS = "POINTS"
    NETWORK = "NETWORK"
    POLYGON_ID_FIELD = "POLYGON_ID_FIELD"
    POINT_ID_FIELD = "POINT_ID_FIELD"
    METHOD = "METHOD"
    UNIQUE_POINTS = "UNIQUE_POINTS"
    OPTIMAL_MATCHING = "OPTIMAL_MATCHING"
    FTTH_LOGICAL_MATCHING = "FTTH_LOGICAL_MATCHING"
    MERGE_CONNECTED_SEGMENTS = "MERGE_CONNECTED_SEGMENTS"
    REPAIR_GAPS = "REPAIR_GAPS"
    GAP_TOLERANCE = "GAP_TOLERANCE"
    SNAP_DISTANCE = "SNAP_DISTANCE"
    CANDIDATE_COUNT = "CANDIDATE_COUNT"
    CONSOLIDATE_ROUTES = "CONSOLIDATE_ROUTES"
    OUTPUT = "OUTPUT"

    METHOD_AERIAL = 0
    METHOD_NETWORK = 1

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POLYGONS, "Panden / polygonen", [QgsProcessing.TypeVectorPolygon]
        ))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POINTS, "Kabel-eindpunten", [QgsProcessing.TypeVectorPoint]
        ))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.NETWORK, "Routeringsnetwerk / tracé", [QgsProcessing.TypeVectorLine]
        ))
        self.addParameter(QgsProcessingParameterField(
            self.POLYGON_ID_FIELD,
            "Pand-ID veld (optioneel; leeg = feature-ID)",
            parentLayerParameterName=self.POLYGONS,
            optional=True,
        ))
        self.addParameter(QgsProcessingParameterField(
            self.POINT_ID_FIELD,
            "Kabelpunt-ID veld (optioneel; leeg = feature-ID)",
            parentLayerParameterName=self.POINTS,
            optional=True,
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.METHOD,
            "Zoekmethode kabelpunt",
            options=[
                "Hemelsbreed dichtstbijzijnde beschikbare kabelpunt",
                "Kortste route via tracé naar beschikbare kabelpunt",
            ],
            defaultValue=0,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.UNIQUE_POINTS,
            "Kabelpunt maximaal 1x gebruiken",
            defaultValue=True,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.OPTIMAL_MATCHING,
            "Optimale pand-punt toewijzing",
            defaultValue=True,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.FTTH_LOGICAL_MATCHING,
            "FTTH-logische matching zonder onlogische swaps",
            defaultValue=True,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.MERGE_CONNECTED_SEGMENTS,
            "Aaneengesloten geconsolideerde segmenten samenvoegen",
            defaultValue=True,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.REPAIR_GAPS,
            "Kleine tracé-onderbrekingen automatisch verbinden",
            defaultValue=True,
        ))
        self.addParameter(QgsProcessingParameterDistance(
            self.GAP_TOLERANCE,
            "Maximale gap-afstand tracéherstel",
            defaultValue=0.5,
            parentParameterName=self.NETWORK,
            minValue=0.0,
        ))
        self.addParameter(QgsProcessingParameterDistance(
            self.SNAP_DISTANCE,
            "Maximale snapafstand naar netwerk",
            defaultValue=100.0,
            parentParameterName=self.POLYGONS,
            minValue=0.0,
        ))
        self.addParameter(QgsProcessingParameterBoolean(
            self.CONSOLIDATE_ROUTES,
            "Routes consolideren / dubbellengtes verwijderen",
            defaultValue=False,
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.CANDIDATE_COUNT,
            "Aantal kandidaatpunten per pand",
            type=QgsProcessingParameterNumber.Integer,
            defaultValue=25,
            minValue=1,
        ))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, "Brils Routes", QgsProcessing.TypeVectorLine
        ))

    def processAlgorithm(self, parameters, context, feedback):
        polygons = self.parameterAsSource(parameters, self.POLYGONS, context)
        points_source = self.parameterAsSource(parameters, self.POINTS, context)
        network = self.parameterAsSource(parameters, self.NETWORK, context)

        polygon_id_field = self.parameterAsString(parameters, self.POLYGON_ID_FIELD, context)
        point_id_field = self.parameterAsString(parameters, self.POINT_ID_FIELD, context)
        method = self.parameterAsEnum(parameters, self.METHOD, context)
        unique_points = self.parameterAsBoolean(parameters, self.UNIQUE_POINTS, context)
        optimal_matching = self.parameterAsBoolean(parameters, self.OPTIMAL_MATCHING, context)
        ftth_logical_matching = self.parameterAsBoolean(parameters, self.FTTH_LOGICAL_MATCHING, context)
        merge_connected_segments = self.parameterAsBoolean(parameters, self.MERGE_CONNECTED_SEGMENTS, context)
        repair_gaps = self.parameterAsBoolean(parameters, self.REPAIR_GAPS, context)
        gap_tolerance = self.parameterAsDouble(parameters, self.GAP_TOLERANCE, context)
        max_snap = self.parameterAsDouble(parameters, self.SNAP_DISTANCE, context)
        consolidate_routes = self.parameterAsBoolean(parameters, self.CONSOLIDATE_ROUTES, context)
        candidate_count = self.parameterAsInt(parameters, self.CANDIDATE_COUNT, context)

        if polygons is None or points_source is None or network is None:
            raise QgsProcessingException("Panden, punten of netwerk kon niet worden gelezen.")
        if polygons.sourceCrs() != points_source.sourceCrs() or polygons.sourceCrs() != network.sourceCrs():
            raise QgsProcessingException("Panden, punten en netwerk moeten hetzelfde CRS hebben.")

        fields = QgsFields()
        fields.append(QgsField("pand_id", QVariant.String))
        fields.append(QgsField("punt_id", QVariant.String))
        fields.append(QgsField("lengte_m", QVariant.Double))
        fields.append(QgsField("hemels_m", QVariant.Double))
        fields.append(QgsField("snap_a_m", QVariant.Double))
        fields.append(QgsField("snap_b_m", QVariant.Double))
        fields.append(QgsField("pand_trace_m", QVariant.Double))
        fields.append(QgsField("methode", QVariant.String))
        fields.append(QgsField("status", QVariant.String))
        fields.append(QgsField("segment_id", QVariant.String))
        fields.append(QgsField("gebruikers", QVariant.Int))
        fields.append(QgsField("route_ids", QVariant.String))

        sink, dest_id = self.parameterAsSink(
            parameters, self.OUTPUT, context, fields, QgsWkbTypes.LineString, polygons.sourceCrs()
        )

        feedback.pushInfo("Kabelpunten voorbereiden...")
        point_index = QgsSpatialIndex()
        point_data = {}

        for pf in points_source.getFeatures():
            pt = point_from_feature(pf)
            if pt is None:
                continue

            fid = int(pf.id())
            point_data[fid] = {
                "feature": pf,
                "point": pt,
                "id": feature_id_value(pf, point_id_field),
            }

            idx_feat = QgsFeature()
            idx_feat.setId(fid)
            idx_feat.setGeometry(QgsGeometry.fromPointXY(pt))
            point_index.addFeature(idx_feat)

        if not point_data:
            raise QgsProcessingException("Geen geldige kabel-eindpunten gevonden.")

        feedback.pushInfo("Netwerk voorbereiden...")
        base_graph, base_points, segments, spatial_index = build_network(network, feedback, repair_gaps, gap_tolerance)
        feedback.pushInfo(f"Netwerksegmenten: {len(segments)}")
        feedback.pushInfo(f"Kabelpunten: {len(point_data)}")

        polygon_items = []
        for poly in polygons.getFeatures():
            polygon_items.append({
                "feature": poly,
                "pand_id": feature_id_value(poly, polygon_id_field),
                "geometry": poly.geometry(),
            })

        ok = 0
        failed = 0
        successful_routes = []

        if unique_points and optimal_matching:
            feedback.pushInfo("Optimale pand-punt toewijzing voorbereiden...")
            if ftth_logical_matching:
                assignments, failed_items = self._ftth_logical_assignments(
                    polygon_items,
                    point_index,
                    point_data,
                    method,
                    candidate_count,
                    base_graph,
                    base_points,
                    segments,
                    spatial_index,
                    max_snap,
                    feedback,
                )
            else:
                assignments, failed_items = self._optimal_assignments(
                    polygon_items,
                    point_index,
                    point_data,
                    method,
                    candidate_count,
                    base_graph,
                    base_points,
                    segments,
                    spatial_index,
                    max_snap,
                    feedback,
                )

            for item in failed_items:
                self._add_failed(sink, fields, item["pand_id"], "FAILED_NO_AVAILABLE_POINT")
                failed += 1
                feedback.pushInfo(f"Pand {item['pand_id']} FAILED: geen routeerbaar kabelpunt.")

            for item, selected in assignments:
                if feedback.isCanceled():
                    break

                self._write_route_feature(
                    sink, fields, item["pand_id"], selected, method,
                    consolidate_routes, successful_routes, feedback
                )
                ok += 1

        else:
            used = set()
            total = len(polygon_items) or 1

            for idx, item in enumerate(polygon_items):
                if feedback.isCanceled():
                    break

                feedback.setProgress(int((idx / total) * 100))
                selected = self._select_single(
                    item["geometry"],
                    point_index,
                    point_data,
                    used,
                    unique_points,
                    method,
                    candidate_count,
                    base_graph,
                    base_points,
                    segments,
                    spatial_index,
                    max_snap,
                )

                if selected is None:
                    self._add_failed(sink, fields, item["pand_id"], "FAILED_NO_AVAILABLE_POINT")
                    failed += 1
                    feedback.pushInfo(f"Pand {item['pand_id']} FAILED: geen beschikbaar kabelpunt.")
                    continue

                self._write_route_feature(
                    sink, fields, item["pand_id"], selected, method,
                    consolidate_routes, successful_routes, feedback
                )

                if unique_points:
                    used.add(selected["fid"])
                ok += 1

        if consolidate_routes:
            feedback.pushInfo("Routes consolideren: overlappende segmenten worden één keer geteld...")
            self._write_consolidated_routes(sink, fields, successful_routes, merge_connected_segments)
            total_unique = sum(item["length"] for item in self._collect_consolidated_segments(successful_routes).values())
            logical_total = sum(item["length"] for item in successful_routes)
            feedback.pushInfo(f"Logische routelengte: {logical_total:.3f} m")
            feedback.pushInfo(f"Geconsolideerde aanleglengte: {total_unique:.3f} m")

        feedback.setProgress(100)
        feedback.pushInfo(f"Klaar. OK: {ok}. FAILED: {failed}.")
        return {self.OUTPUT: dest_id}


    def _building_trace_start(self, poly_geom, segments, spatial_index, max_snap):
        # Nieuwe hoofdregel:
        # 1. zoek eerst het dichtstbijzijnde tracé bij het pand;
        # 2. als tracé het pand raakt/doorsnijdt, gebruik dat tracépunt;
        # 3. anders gebruik het dichtstbijzijnde punt op de pandrand richting dat tracé.
        if poly_geom is None or poly_geom.isEmpty():
            return None, None, None, "FAILED_EMPTY_POLYGON"

        centroid = QgsPointXY(poly_geom.centroid().asPoint())
        nearest = find_nearest_segment(centroid, segments, spatial_index, max_snap * 10)

        # Als centroid-zoekbox niets vindt, probeer ruim.
        if nearest is None:
            nearest = find_nearest_segment(centroid, segments, spatial_index, max_snap)

        if nearest is None:
            return None, None, None, "FAILED_NO_TRACE_NEAR_BUILDING"

        trace_pt = nearest["point"]

        # Dichtstbijzijnde pandrand naar het gekozen tracépunt.
        boundary_pt = polygon_boundary_start_point(poly_geom, trace_pt)
        if boundary_pt is None:
            return None, None, None, "FAILED_NO_POLYGON_BOUNDARY"

        # Als het tracé het pand raakt/snijdt, moet de aansluiting 0 zijn.
        # We testen dit via afstand van tracépunt tot pandgeometrie.
        trace_geom = QgsGeometry.fromPointXY(trace_pt)
        trace_inside_or_touching = poly_geom.distance(trace_geom) <= 0.001

        if trace_inside_or_touching:
            return trace_pt, trace_pt, 0.0, "OK_TRACE_TOUCHES_BUILDING"

        connection_dist = ((boundary_pt.x() - trace_pt.x()) ** 2 + (boundary_pt.y() - trace_pt.y()) ** 2) ** 0.5

        if connection_dist > max_snap:
            return boundary_pt, trace_pt, connection_dist, f"FAILED_BUILDING_TRACE_SNAP_{connection_dist:.3f}"

        return boundary_pt, trace_pt, connection_dist, "OK_TRACE_CONNECTED_BUILDING"

    def _candidate_options(
        self, poly_geom, point_index, point_data, method, candidate_count,
        base_graph, base_points, segments, spatial_index, max_snap
    ):
        if poly_geom is None or poly_geom.isEmpty():
            return []

        c = QgsPointXY(poly_geom.centroid().asPoint())
        max_candidates = len(point_data) if method == self.METHOD_AERIAL else min(len(point_data), candidate_count * 4)
        candidate_ids = point_index.nearestNeighbor(c, max_candidates)

        options = []
        checked = 0

        for fid in candidate_ids:
            if fid not in point_data:
                continue

            end_pt = point_data[fid]["point"]

            start_pt, trace_pt, building_trace_dist, start_status = self._building_trace_start(
                poly_geom, segments, spatial_index, max_snap
            )

            if start_pt is None or start_status.startswith("FAILED"):
                continue

            aerial = dist(start_pt, end_pt)

            # V4.8:
            # Eerst pand -> gekozen tracépunt vastzetten.
            # Daarna vanaf dat exacte tracépunt over het netwerk naar het kabelpunt routeren.
            # Zo kiest de router niet opnieuw een ander "dichtstbijzijnd" tracésegment bij het pand.
            route_geom, snap_a, snap_b, status = route_between_points(
                trace_pt, end_pt, base_graph, base_points, segments, spatial_index, max_snap
            )

            if status == "OK" and route_geom is not None and dist(start_pt, trace_pt) > 0.001:
                net_pts = route_geom.asPolyline() if not route_geom.isMultipart() else route_geom.asMultiPolyline()[0]
                route_geom = QgsGeometry.fromPolylineXY([QgsPointXY(start_pt)] + [QgsPointXY(p) for p in net_pts])
                snap_a = building_trace_dist

            checked += 1

            if status == "OK" and route_geom is not None:
                route_len = route_geom.length()

                # V4.8 hoofdregel:
                # kies op basis van kortste totale route pand -> vast tracépunt -> kabelpunt.
                cost = route_len

                options.append({
                    "fid": fid,
                    "id": point_data[fid]["id"],
                    "point": end_pt,
                    "start": start_pt,
                    "aerial": aerial,
                    "length": route_len,
                    "route_geom": route_geom,
                    "snap_a": snap_a,
                    "snap_b": snap_b,
                    "pand_trace_m": building_trace_dist,
                    "status": status,
                    "cost": cost,
                })

            if method == self.METHOD_NETWORK and checked >= candidate_count:
                break

        options.sort(key=lambda x: x["cost"])
        return options

    def _select_single(
        self, poly_geom, point_index, point_data, used, unique, method, candidate_count,
        base_graph, base_points, segments, spatial_index, max_snap
    ):
        options = self._candidate_options(
            poly_geom, point_index, point_data, method, candidate_count,
            base_graph, base_points, segments, spatial_index, max_snap
        )

        for opt in options:
            if not unique or opt["fid"] not in used:
                return opt

        return None


    def _project_point_on_network_measure(self, point, segments, spatial_index):
        # Robuuste pseudo-chainage: dichtstbijzijnde netwerksegment + positie binnen segment.
        # Dit behoudt lokale volgorde langs het tracé veel beter dan pure globale kostenmatching.
        best = None
        candidate_ids = spatial_index.nearestNeighbor(point, 50)

        for seg_id in candidate_ids:
            if seg_id < 0 or seg_id >= len(segments):
                continue

            a, b = segments[seg_id]
            cp = self._closest_point_for_measure(point, a, b)
            d = ((point.x() - cp["point"].x()) ** 2 + (point.y() - cp["point"].y()) ** 2) ** 0.5

            if best is None or d < best["dist"]:
                best = {
                    "segment": seg_id,
                    "t": cp["t"],
                    "dist": d,
                    "measure": seg_id + cp["t"],
                }

        return best["measure"] if best else 0.0

    def _closest_point_for_measure(self, p, a, b):
        ax, ay = a.x(), a.y()
        bx, by = b.x(), b.y()
        px, py = p.x(), p.y()
        dx = bx - ax
        dy = by - ay
        length_sq = dx * dx + dy * dy

        if length_sq == 0:
            return {"point": QgsPointXY(a), "t": 0.0}

        t = ((px - ax) * dx + (py - ay) * dy) / length_sq
        t = max(0.0, min(1.0, t))
        return {"point": QgsPointXY(ax + t * dx, ay + t * dy), "t": t}

    def _ftth_logical_assignments(
        self, polygon_items, point_index, point_data, method, candidate_count,
        base_graph, base_points, segments, spatial_index, max_snap, feedback
    ):
        # FTTH-logica:
        # 1. bepaal voor ieder pand routeerbare opties;
        # 2. projecteer pand-start en kabelpunt op tracé;
        # 3. verwerk panden in tracévolgorde;
        # 4. kies dichtbijzijnde beschikbare kabelpunten met sterke straf voor volgorde-swaps.
        prepared = []
        failed_items = []
        total = len(polygon_items) or 1

        feedback.pushInfo("FTTH-logische matching: pand-tracépunt vastzetten en kortste totale route naar kabelpunt berekenen...")

        for idx, item in enumerate(polygon_items):
            if feedback.isCanceled():
                break

            feedback.setProgress(int((idx / total) * 45))

            options = self._candidate_options(
                item["geometry"], point_index, point_data, method, candidate_count,
                base_graph, base_points, segments, spatial_index, max_snap
            )

            if not options:
                failed_items.append(item)
                continue

            # Gebruik beste optie alleen voor het bepalen van de pandpositie langs tracé.
            anchor = options[0]["start"]
            item_measure = self._project_point_on_network_measure(anchor, segments, spatial_index)

            for opt in options:
                opt["point_measure"] = self._project_point_on_network_measure(opt["point"], segments, spatial_index)

            prepared.append({
                "item": item,
                "measure": item_measure,
                "options": options,
            })

        prepared.sort(key=lambda x: x["measure"])

        used_points = set()
        assignments = []
        last_point_measure = None

        for row in prepared:
            item_measure = row["measure"]
            best = None
            best_score = None

            for opt in row["options"]:
                if opt["fid"] in used_points:
                    continue

                point_measure = opt["point_measure"]

                # Basis-score: totale route pand -> kabelpunt.
                score = opt["cost"]

                # Sterke, maar niet oneindige, straf bij volgorde-terugloop.
                # Kortste logische route blijft leidend, swaps worden ontmoedigd.
                if last_point_measure is not None and point_measure < last_point_measure:
                    score += 250.0 + (last_point_measure - point_measure) * 0.25

                # Lichte straf voor pand/punt die ver uit elkaar liggen langs tracé.
                score += abs(point_measure - item_measure) * 0.005

                if best_score is None or score < best_score:
                    best_score = score
                    best = opt

            if best is None:
                failed_items.append(row["item"])
                continue

            used_points.add(best["fid"])
            last_point_measure = best["point_measure"]
            assignments.append((row["item"], best))

        feedback.pushInfo(f"FTTH-logische matching: {len(assignments)} gekoppeld, {len(failed_items)} mislukt.")
        return assignments, failed_items

    def _optimal_assignments(
        self, polygon_items, point_index, point_data, method, candidate_count,
        base_graph, base_points, segments, spatial_index, max_snap, feedback
    ):
        # Min-cost matching: 1 pand -> max 1 punt, 1 punt -> max 1 pand.
        edge_options = []
        failed_items = []
        point_ids = set()
        active_items = []

        total = len(polygon_items) or 1

        for idx, item in enumerate(polygon_items):
            if feedback.isCanceled():
                break

            feedback.setProgress(int((idx / total) * 45))
            options = self._candidate_options(
                item["geometry"], point_index, point_data, method, candidate_count,
                base_graph, base_points, segments, spatial_index, max_snap
            )

            if not options:
                failed_items.append(item)
                continue

            active_idx = len(active_items)
            active_items.append(item)

            for opt in options:
                point_ids.add(opt["fid"])
                edge_options.append((active_idx, opt["fid"], opt))

        if not active_items:
            return [], failed_items

        point_list = sorted(point_ids)
        point_pos = {fid: i for i, fid in enumerate(point_list)}

        n_left = len(active_items)
        n_right = len(point_list)
        source = 0
        left_offset = 1
        right_offset = left_offset + n_left
        sink = right_offset + n_right
        node_count = sink + 1

        graph = [[] for _ in range(node_count)]

        def add_arc(u, v, cap, cost, payload=None):
            graph[u].append([v, cap, cost, len(graph[v]), payload])
            graph[v].append([u, 0, -cost, len(graph[u]) - 1, None])

        for i in range(n_left):
            add_arc(source, left_offset + i, 1, 0)

        option_by_edge = {}

        for left_idx, point_fid, opt in edge_options:
            u = left_offset + left_idx
            v = right_offset + point_pos[point_fid]
            scaled_cost = int(round(opt["cost"] * 1000.0))
            edge_index = len(graph[u])
            add_arc(u, v, 1, scaled_cost, opt)
            option_by_edge[(u, edge_index)] = opt

        for fid in point_list:
            add_arc(right_offset + point_pos[fid], sink, 1, 0)

        flow_needed = n_left
        flow = 0
        potentials = [0] * node_count

        while flow < flow_needed:
            dist_arr = [10**30] * node_count
            prev_node = [-1] * node_count
            prev_edge = [-1] * node_count
            dist_arr[source] = 0
            queue = [(0, source)]

            while queue:
                cur_dist, u = heapq.heappop(queue)
                if cur_dist != dist_arr[u]:
                    continue

                for ei, edge in enumerate(graph[u]):
                    v, cap, cost, rev, payload = edge
                    if cap <= 0:
                        continue

                    reduced = cost + potentials[u] - potentials[v]
                    nd = cur_dist + reduced

                    if nd < dist_arr[v]:
                        dist_arr[v] = nd
                        prev_node[v] = u
                        prev_edge[v] = ei
                        heapq.heappush(queue, (nd, v))

            if prev_node[sink] == -1:
                # Niet alle panden kunnen uniek gekoppeld worden.
                for i in range(flow, n_left):
                    failed_items.append(active_items[i])
                break

            for i in range(node_count):
                if dist_arr[i] < 10**30:
                    potentials[i] += dist_arr[i]

            v = sink
            while v != source:
                u = prev_node[v]
                ei = prev_edge[v]
                edge = graph[u][ei]
                edge[1] -= 1
                graph[v][edge[3]][1] += 1
                v = u

            flow += 1

        assignments = []

        for left_idx, item in enumerate(active_items):
            u = left_offset + left_idx
            selected = None

            for edge in graph[u]:
                # Originele forward edge naar rechterzijde heeft cap 0 na gebruik.
                v, cap, cost, rev, payload = edge
                if right_offset <= v < right_offset + n_right and payload is not None and cap == 0:
                    selected = payload
                    break

            if selected is None:
                failed_items.append(item)
            else:
                assignments.append((item, selected))

        feedback.pushInfo(f"Optimale toewijzing: {len(assignments)} gekoppeld, {len(failed_items)} mislukt.")
        return assignments, failed_items

    def _write_route_feature(self, sink, fields, pand_id, selected, method, consolidate_routes, successful_routes, feedback):
        route_geom = selected["route_geom"]
        snap_a = selected["snap_a"]
        snap_b = selected["snap_b"]
        status = selected["status"]

        feat = QgsFeature(fields)
        feat["pand_id"] = pand_id
        feat["punt_id"] = selected["id"]
        feat["hemels_m"] = round(selected["aerial"], 3)
        feat["methode"] = "HEMELSBREED" if method == self.METHOD_AERIAL else "VIA_TRACE"
        feat["status"] = status

        if status == "OK" and route_geom is not None:
            feat["lengte_m"] = round(route_geom.length(), 3)
            feat["snap_a_m"] = round(snap_a, 3)
            feat["snap_b_m"] = round(snap_b, 3)
            feat["pand_trace_m"] = round(selected.get("pand_trace_m", 0.0), 3)
            feat.setGeometry(route_geom)

            successful_routes.append({
                "pand_id": pand_id,
                "punt_id": selected["id"],
                "geometry": route_geom,
                "length": route_geom.length(),
                "hemels": selected["aerial"],
                "snap_a": snap_a,
                "snap_b": snap_b,
                "pand_trace_m": selected.get("pand_trace_m", 0.0),
                "method": "HEMELSBREED" if method == self.METHOD_AERIAL else "VIA_TRACE",
            })

            feedback.pushInfo(f"Pand {pand_id} -> punt {selected['id']} OK | {route_geom.length():.3f} m")
        else:
            feedback.pushInfo(f"Pand {pand_id} -> punt {selected['id']} {status}")

        if not consolidate_routes or status != "OK":
            sink.addFeature(feat)

    def _segment_key(self, a, b):
        ka = (round(a.x(), 3), round(a.y(), 3))
        kb = (round(b.x(), 3), round(b.y(), 3))
        return tuple(sorted([ka, kb]))

    def _collect_consolidated_segments(self, successful_routes):
        segments = {}

        for route in successful_routes:
            geom = route["geometry"]
            if geom is None or geom.isEmpty():
                continue

            if geom.isMultipart():
                lines = geom.asMultiPolyline()
            else:
                lines = [geom.asPolyline()]

            for line in lines:
                for i in range(len(line) - 1):
                    a = QgsPointXY(line[i])
                    b = QgsPointXY(line[i + 1])

                    if a == b:
                        continue

                    skey = self._segment_key(a, b)

                    if skey not in segments:
                        segments[skey] = {
                            "a": a,
                            "b": b,
                            "length": dist(a, b),
                            "pand_ids": set(),
                            "punt_ids": set(),
                        }

                    segments[skey]["pand_ids"].add(str(route["pand_id"]))
                    segments[skey]["punt_ids"].add(str(route["punt_id"]))

        return segments


    def _write_consolidated_routes(self, sink, fields, successful_routes, merge_connected_segments=True):
        segments = self._collect_consolidated_segments(successful_routes)

        if merge_connected_segments:
            merged_lines = self._merge_consolidated_segments(segments)

            for idx, item in enumerate(merged_lines, start=1):
                feat = QgsFeature(fields)
                feat["lengte_m"] = round(item["length"], 3)
                feat["status"] = "OK_CONSOLIDATED_MERGED"
                feat["segment_id"] = f"M{idx}"
                feat["gebruikers"] = len(item["pand_ids"])
                feat["route_ids"] = ",".join(sorted(item["pand_ids"]))
                feat["pand_id"] = ",".join(sorted(item["pand_ids"]))
                feat["punt_id"] = ",".join(sorted(item["punt_ids"]))
                feat.setGeometry(QgsGeometry.fromPolylineXY(item["points"]))
                sink.addFeature(feat)
        else:
            for idx, item in enumerate(segments.values(), start=1):
                feat = QgsFeature(fields)
                feat["lengte_m"] = round(item["length"], 3)
                feat["status"] = "OK_CONSOLIDATED"
                feat["segment_id"] = f"S{idx}"
                feat["gebruikers"] = len(item["pand_ids"])
                feat["route_ids"] = ",".join(sorted(item["pand_ids"]))
                feat["pand_id"] = ",".join(sorted(item["pand_ids"]))
                feat["punt_id"] = ",".join(sorted(item["punt_ids"]))
                feat.setGeometry(QgsGeometry.fromPolylineXY([item["a"], item["b"]]))
                sink.addFeature(feat)

    def _merge_consolidated_segments(self, segments):
        # Merge alleen door nodes met graad 2. Bij kruisingen/vertakkingen wordt gestopt.
        adjacency = {}
        edge_data = {}

        for skey, item in segments.items():
            a = item["a"]
            b = item["b"]
            ka = self._node_key(a)
            kb = self._node_key(b)

            edge_id = len(edge_data)
            edge_data[edge_id] = {
                "a_key": ka,
                "b_key": kb,
                "a": a,
                "b": b,
                "length": item["length"],
                "pand_ids": set(item["pand_ids"]),
                "punt_ids": set(item["punt_ids"]),
            }

            adjacency.setdefault(ka, []).append(edge_id)
            adjacency.setdefault(kb, []).append(edge_id)

        visited = set()
        merged = []

        for edge_id in list(edge_data.keys()):
            if edge_id in visited:
                continue

            edge = edge_data[edge_id]

            # Start bij een eind-/vertaknode als die er is; anders bij a_key.
            start_node = edge["a_key"]
            if len(adjacency.get(edge["b_key"], [])) != 2:
                start_node = edge["b_key"]
            if len(adjacency.get(edge["a_key"], [])) != 2:
                start_node = edge["a_key"]

            chain_edges = []
            current_node = start_node
            previous_edge = None

            while True:
                next_edge = None

                for eid in adjacency.get(current_node, []):
                    if eid != previous_edge and eid not in visited:
                        next_edge = eid
                        break

                if next_edge is None:
                    break

                visited.add(next_edge)
                chain_edges.append((next_edge, current_node))
                e = edge_data[next_edge]
                current_node = e["b_key"] if current_node == e["a_key"] else e["a_key"]

                # Stop op eindpunt, kruising of vertakking.
                if len(adjacency.get(current_node, [])) != 2:
                    break

                previous_edge = next_edge

            if not chain_edges:
                continue

            points = []
            total_length = 0.0
            pand_ids = set()
            punt_ids = set()

            for i, (eid, from_node) in enumerate(chain_edges):
                e = edge_data[eid]
                if from_node == e["a_key"]:
                    p1, p2 = e["a"], e["b"]
                else:
                    p1, p2 = e["b"], e["a"]

                if i == 0:
                    points.append(QgsPointXY(p1))
                points.append(QgsPointXY(p2))

                total_length += e["length"]
                pand_ids.update(e["pand_ids"])
                punt_ids.update(e["punt_ids"])

            merged.append({
                "points": points,
                "length": total_length,
                "pand_ids": pand_ids,
                "punt_ids": punt_ids,
            })

        return merged

    def _node_key(self, pt):
        return (round(pt.x(), 3), round(pt.y(), 3))

    def _add_failed(self, sink, fields, pand_id, status):
        feat = QgsFeature(fields)
        feat["pand_id"] = pand_id
        feat["status"] = status
        sink.addFeature(feat)

    def name(self):
        return "route_panden_naar_kabelpunten"

    def displayName(self):
        return "Route Panden Naar Kabelpunten"

    def group(self):
        return "Routing"

    def groupId(self):
        return "routing"

    def createInstance(self):
        return RouteBuildingsAlgorithm()
