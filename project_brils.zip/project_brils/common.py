from qgis.core import QgsFeature, QgsGeometry, QgsPointXY, QgsRectangle, QgsSpatialIndex, QgsWkbTypes, QgsProcessingException
import heapq
import math


def key(pt):
    return (round(pt.x(), 6), round(pt.y(), 6))


def dist(a, b):
    return math.hypot(a.x() - b.x(), a.y() - b.y())


def geometry_to_lines(geom):
    if geom is None or geom.isEmpty():
        return []
    if geom.isMultipart():
        return geom.asMultiPolyline()
    return [geom.asPolyline()]


def add_edge(graph, points, a, b):
    ka = key(a)
    kb = key(b)
    if ka == kb:
        return
    points[ka] = QgsPointXY(a)
    points[kb] = QgsPointXY(b)
    length = dist(a, b)
    graph.setdefault(ka, []).append((kb, length))
    graph.setdefault(kb, []).append((ka, length))


def closest_point_on_segment(p, a, b):
    ax, ay = a.x(), a.y()
    bx, by = b.x(), b.y()
    px, py = p.x(), p.y()
    dx = bx - ax
    dy = by - ay
    length_sq = dx * dx + dy * dy

    if length_sq == 0:
        return QgsPointXY(a)

    t = ((px - ax) * dx + (py - ay) * dy) / length_sq
    t = max(0.0, min(1.0, t))
    return QgsPointXY(ax + t * dx, ay + t * dy)


def dijkstra(graph, start_key, end_key):
    queue = [(0.0, start_key)]
    costs = {start_key: 0.0}
    previous = {}

    while queue:
        cost, node = heapq.heappop(queue)

        if node == end_key:
            break

        if cost > costs[node]:
            continue

        for next_node, edge_cost in graph.get(node, []):
            new_cost = cost + edge_cost

            if next_node not in costs or new_cost < costs[next_node]:
                costs[next_node] = new_cost
                previous[next_node] = node
                heapq.heappush(queue, (new_cost, next_node))

    if end_key not in costs:
        return None, None

    path = [end_key]
    while path[-1] != start_key:
        path.append(previous[path[-1]])

    path.reverse()
    return path, costs[end_key]




def build_network(network_source, feedback=None, repair_gaps=False, gap_tolerance=0.1):
    # V5.0.5:
    # - Eerst netwerksegmenten verzamelen.
    # - Daarna graph-basis opbouwen.
    # - Daarna alleen echte open eindpunten (degree == 1) herstellen.
    # - Geen massale vertex-naar-vertex koppelingen meer.
    raw_segments = []

    for nf in network_source.getFeatures():
        if feedback and feedback.isCanceled():
            break

        for line in geometry_to_lines(nf.geometry()):
            if len(line) < 2:
                continue

            clean_line = [QgsPointXY(p) for p in line]

            for i in range(len(clean_line) - 1):
                a = clean_line[i]
                b = clean_line[i + 1]

                if key(a) == key(b):
                    continue

                raw_segments.append((a, b, False))

    if not raw_segments:
        raise QgsProcessingException("Geen bruikbare netwerksegmenten gevonden.")

    base_graph = {}
    base_points = {}
    segments = []
    spatial_index = QgsSpatialIndex()
    degree = {}

    gap_penalty_factor = 100.0

    def add_segment(a, b, is_gap):
        a = QgsPointXY(a)
        b = QgsPointXY(b)

        if key(a) == key(b):
            return

        seg_id = len(segments)
        segments.append((a, b))

        ka = key(a)
        kb = key(b)
        base_points[ka] = a
        base_points[kb] = b

        length = dist(a, b)
        cost = length * gap_penalty_factor if is_gap else length

        base_graph.setdefault(ka, []).append((kb, cost))
        base_graph.setdefault(kb, []).append((ka, cost))

        degree[ka] = degree.get(ka, 0) + 1
        degree[kb] = degree.get(kb, 0) + 1

        sf = QgsFeature()
        sf.setId(seg_id)
        sf.setGeometry(QgsGeometry.fromPolylineXY([a, b]))
        spatial_index.addFeature(sf)

    for a, b, is_gap in raw_segments:
        add_segment(a, b, is_gap)

    repaired = 0
    open_endpoint_count = 0

    if repair_gaps and gap_tolerance > 0:
        open_nodes = [node_key for node_key, deg in degree.items() if deg == 1]
        open_endpoint_count = len(open_nodes)

        endpoint_index = QgsSpatialIndex()
        endpoint_items = []

        for idx, node_key in enumerate(open_nodes):
            pt = base_points[node_key]
            feat = QgsFeature()
            feat.setId(idx)
            feat.setGeometry(QgsGeometry.fromPointXY(pt))
            endpoint_index.addFeature(feat)
            endpoint_items.append({
                "node_key": node_key,
                "point": pt,
                "used": False,
            })

        # Kandidaten globaal sorteren op afstand. Daardoor wordt altijd de kortste
        # beschikbare gap eerst gekoppeld, maximaal 1 verbinding per open eindpunt.
        candidates = []

        for i, item in enumerate(endpoint_items):
            if feedback and feedback.isCanceled():
                break

            p = item["point"]
            rect = QgsRectangle(
                p.x() - gap_tolerance,
                p.y() - gap_tolerance,
                p.x() + gap_tolerance,
                p.y() + gap_tolerance,
            )

            for j in endpoint_index.intersects(rect):
                if j <= i or j < 0 or j >= len(endpoint_items):
                    continue

                q = endpoint_items[j]["point"]
                d = dist(p, q)

                if d <= 0.000001 or d > gap_tolerance:
                    continue

                candidates.append((d, i, j))

        candidates.sort(key=lambda x: x[0])

        for d, i, j in candidates:
            if endpoint_items[i]["used"] or endpoint_items[j]["used"]:
                continue

            p = endpoint_items[i]["point"]
            q = endpoint_items[j]["point"]

            add_segment(p, q, True)
            endpoint_items[i]["used"] = True
            endpoint_items[j]["used"] = True
            repaired += 1

    if feedback and repair_gaps:
        feedback.pushInfo(
            f"Open eindpunten: {open_endpoint_count}. "
            f"Auto herstel netwerk-gaps: {repaired} tijdelijke verbinding(en) toegevoegd binnen {gap_tolerance:.3f} m."
        )

    return base_graph, base_points, segments, spatial_index


def find_nearest_segment(point, segments, spatial_index, max_snap):
    search_rect = QgsRectangle(
        point.x() - max_snap,
        point.y() - max_snap,
        point.x() + max_snap,
        point.y() + max_snap,
    )
    candidate_ids = spatial_index.intersects(search_rect)

    if not candidate_ids:
        candidate_ids = spatial_index.nearestNeighbor(point, 25)

    best = None

    for seg_id in candidate_ids:
        if seg_id < 0 or seg_id >= len(segments):
            continue

        s1, s2 = segments[seg_id]
        closest = closest_point_on_segment(point, s1, s2)
        d = dist(point, closest)

        if best is None or d < best["dist"]:
            best = {"point": closest, "dist": d, "segment": seg_id}

    return best


def route_between_points(start_pt, end_pt, base_graph, base_points, segments, spatial_index, max_snap):
    best_a = find_nearest_segment(start_pt, segments, spatial_index, max_snap)
    best_b = find_nearest_segment(end_pt, segments, spatial_index, max_snap)

    if best_a is None:
        return None, None, None, "FAILED_A_NO_NETWORK_NEARBY"
    if best_b is None:
        return None, None, None, "FAILED_B_NO_NETWORK_NEARBY"
    if best_a["dist"] > max_snap:
        return None, best_a["dist"], best_b["dist"], f"FAILED_A_SNAP_{best_a['dist']:.3f}"
    if best_b["dist"] > max_snap:
        return None, best_a["dist"], best_b["dist"], f"FAILED_B_SNAP_{best_b['dist']:.3f}"

    graph = {k: list(v) for k, v in base_graph.items()}
    points = dict(base_points)

    snap_a = best_a["point"]
    snap_b = best_b["point"]

    seg_a_1, seg_a_2 = segments[best_a["segment"]]
    seg_b_1, seg_b_2 = segments[best_b["segment"]]

    add_edge(graph, points, snap_a, seg_a_1)
    add_edge(graph, points, snap_a, seg_a_2)
    add_edge(graph, points, snap_b, seg_b_1)
    add_edge(graph, points, snap_b, seg_b_2)

    if best_a["segment"] == best_b["segment"]:
        add_edge(graph, points, snap_a, snap_b)

    add_edge(graph, points, start_pt, snap_a)
    add_edge(graph, points, end_pt, snap_b)

    path_keys, _ = dijkstra(graph, key(start_pt), key(end_pt))

    if not path_keys:
        return None, best_a["dist"], best_b["dist"], "FAILED_NO_ROUTE"

    route_pts = [points[k] for k in path_keys]
    return QgsGeometry.fromPolylineXY(route_pts), best_a["dist"], best_b["dist"], "OK"


def first_line_points(geom):
    lines = geometry_to_lines(geom)
    return lines[0] if lines else []


def feature_id_value(feature, id_field):
    if id_field:
        try:
            value = feature[id_field]
            if value is not None and str(value).upper() != "NULL":
                return str(value)
        except Exception:
            pass
    return str(feature.id())


def point_from_feature(feature):
    geom = feature.geometry()
    if geom is None or geom.isEmpty():
        return None
    if QgsWkbTypes.geometryType(geom.wkbType()) != QgsWkbTypes.PointGeometry:
        return None
    if geom.isMultipart():
        pts = geom.asMultiPoint()
        return QgsPointXY(pts[0]) if pts else None
    return QgsPointXY(geom.asPoint())


def _polygon_rings(poly_geom):
    if poly_geom is None or poly_geom.isEmpty():
        return []

    if poly_geom.isMultipart():
        polys = poly_geom.asMultiPolygon()
        rings = []
        for poly in polys:
            for ring in poly:
                rings.append(ring)
        return rings

    poly = poly_geom.asPolygon()
    return [ring for ring in poly]


def polygon_boundary_start_point(poly_geom, target_point):
    # QGIS 3.44 heeft geen QgsGeometry.boundary() in Python.
    # Daarom bepalen we het dichtstbijzijnde punt op alle polygon-ringen handmatig.
    rings = _polygon_rings(poly_geom)
    if not rings:
        return None

    best_pt = None
    best_dist = None

    for ring in rings:
        if len(ring) < 2:
            continue

        for i in range(len(ring) - 1):
            a = QgsPointXY(ring[i])
            b = QgsPointXY(ring[i + 1])
            cp = closest_point_on_segment(target_point, a, b)
            d = dist(target_point, cp)

            if best_dist is None or d < best_dist:
                best_dist = d
                best_pt = cp

    return best_pt


def apply_brils_neon_style(layer):
    if layer is None:
        return

    try:
        layer.setName("Brils Routes")

        from qgis.core import QgsLineSymbol, QgsSingleSymbolRenderer

        symbol = QgsLineSymbol.createSimple({
            "color": "0,255,0,255",
            "line_width": "1.86",
            "line_width_unit": "MM",
        })

        try:
            from qgis.core import QgsOuterGlowEffect
            effect = QgsOuterGlowEffect.create({
                "enabled": "1",
                "blur_level": "4",
                "spread": "2",
                "color": "0,255,0,255",
                "opacity": "1",
            })
            symbol.symbolLayer(0).setPaintEffect(effect)
        except Exception:
            pass

        layer.setRenderer(QgsSingleSymbolRenderer(symbol))
        layer.triggerRepaint()
    except Exception:
        pass
