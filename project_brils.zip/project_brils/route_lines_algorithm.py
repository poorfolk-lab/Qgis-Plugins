from qgis.core import (
    QgsFeature, QgsField, QgsFields, QgsProcessing, QgsProcessingAlgorithm,
    QgsProcessingException, QgsProcessingParameterBoolean, QgsProcessingParameterDistance, QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource, QgsProcessingParameterField, QgsWkbTypes
)
from qgis.PyQt.QtCore import QVariant
from .common import build_network, feature_id_value, first_line_points, route_between_points


class RouteLinesAlgorithm(QgsProcessingAlgorithm):
    INPUT_LINES = "INPUT_LINES"
    NETWORK = "NETWORK"
    ID_FIELD = "ID_FIELD"
    SNAP_DISTANCE = "SNAP_DISTANCE"
    REPAIR_GAPS = "REPAIR_GAPS"
    GAP_TOLERANCE = "GAP_TOLERANCE"
    OUTPUT = "OUTPUT"

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(self.INPUT_LINES, "Bronlijnen", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSource(self.NETWORK, "Routeringsnetwerk / tracé", [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterField(self.ID_FIELD, "ID-veld bronlijnen (optioneel; leeg = feature-ID)", parentLayerParameterName=self.INPUT_LINES, optional=True))
        self.addParameter(QgsProcessingParameterDistance(self.SNAP_DISTANCE, "Maximale snapafstand naar netwerk", defaultValue=100.0, parentParameterName=self.INPUT_LINES, minValue=0.0))
        self.addParameter(QgsProcessingParameterBoolean(self.REPAIR_GAPS, "Kleine tracé-onderbrekingen automatisch verbinden", defaultValue=True))
        self.addParameter(QgsProcessingParameterDistance(self.GAP_TOLERANCE, "Maximale gap-afstand tracéherstel", defaultValue=0.5, parentParameterName=self.NETWORK, minValue=0.0))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, "Brils Routes", QgsProcessing.TypeVectorLine))

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT_LINES, context)
        network = self.parameterAsSource(parameters, self.NETWORK, context)
        id_field = self.parameterAsString(parameters, self.ID_FIELD, context)
        max_snap = self.parameterAsDouble(parameters, self.SNAP_DISTANCE, context)
        repair_gaps = self.parameterAsBoolean(parameters, self.REPAIR_GAPS, context)
        gap_tolerance = self.parameterAsDouble(parameters, self.GAP_TOLERANCE, context)

        if source is None or network is None:
            raise QgsProcessingException("Bronlijnen of netwerk kon niet worden gelezen.")
        if source.sourceCrs() != network.sourceCrs():
            raise QgsProcessingException("Bronlijnen en netwerk moeten hetzelfde CRS hebben.")

        fields = QgsFields()
        fields.append(QgsField("bron_id", QVariant.String))
        fields.append(QgsField("lengte_m", QVariant.Double))
        fields.append(QgsField("snap_a_m", QVariant.Double))
        fields.append(QgsField("snap_b_m", QVariant.Double))
        fields.append(QgsField("status", QVariant.String))

        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, QgsWkbTypes.LineString, source.sourceCrs())

        feedback.pushInfo("Netwerk voorbereiden...")
        base_graph, base_points, segments, spatial_index = build_network(network, feedback, repair_gaps, gap_tolerance)
        feedback.pushInfo(f"Netwerksegmenten: {len(segments)}")

        total = source.featureCount() or 1
        ok = 0
        failed = 0

        for idx, f in enumerate(source.getFeatures()):
            if feedback.isCanceled():
                break

            feedback.setProgress(int((idx / total) * 100))
            bron_id = feature_id_value(f, id_field)
            pts = first_line_points(f.geometry())

            feat = QgsFeature(fields)
            feat["bron_id"] = bron_id

            if len(pts) < 2:
                feat["status"] = "FAILED_NO_VALID_LINE"
                sink.addFeature(feat)
                failed += 1
                continue

            route_geom, snap_a, snap_b, status = route_between_points(
                pts[0], pts[-1], base_graph, base_points, segments, spatial_index, max_snap
            )

            feat["status"] = status

            if status == "OK" and route_geom is not None:
                feat["lengte_m"] = round(route_geom.length(), 3)
                feat["snap_a_m"] = round(snap_a, 3)
                feat["snap_b_m"] = round(snap_b, 3)
                feat.setGeometry(route_geom)
                ok += 1
                feedback.pushInfo(f"{bron_id} OK | {route_geom.length():.3f} m")
            else:
                failed += 1
                feedback.pushInfo(f"{bron_id} {status}")

            sink.addFeature(feat)

        feedback.setProgress(100)
        feedback.pushInfo(f"Klaar. OK: {ok}. FAILED: {failed}.")
        return {self.OUTPUT: dest_id}

    def name(self): return "route_lijnen"
    def displayName(self): return "Route Lijnen"
    def group(self): return "Routing"
    def groupId(self): return "routing"
    def createInstance(self): return RouteLinesAlgorithm()
