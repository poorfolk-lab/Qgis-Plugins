from qgis.core import (
    QgsFeature,
    QgsField,
    QgsFields,
    QgsGeometry,
    QgsPointXY,
    QgsProcessing,
    QgsProcessingAlgorithm,
    QgsProcessingException,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterDistance,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterFile,
    QgsProcessingParameterString,
    QgsSpatialIndex,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QVariant
from .common import (
    build_network,
    feature_id_value,
    polygon_boundary_start_point,
    route_between_points,
    closest_point_on_segment,
    add_edge,
    dist,
    key,
)
import re


class RoutePandenNaarExcelXYAlgorithm(QgsProcessingAlgorithm):
    POLYGONS = "POLYGONS"
    ADDRESS_POINTS = "ADDRESS_POINTS"
    NETWORK = "NETWORK"
    EXCEL_FILE = "EXCEL_FILE"

    POINT_POSTCODE_FIELD = "POINT_POSTCODE_FIELD"
    POINT_HOUSE_FIELD = "POINT_HOUSE_FIELD"

    EXCEL_POSTCODE_FIELD = "EXCEL_POSTCODE_FIELD"
    EXCEL_HOUSE_FIELD = "EXCEL_HOUSE_FIELD"
    EXCEL_X_FIELD = "EXCEL_X_FIELD"
    EXCEL_Y_FIELD = "EXCEL_Y_FIELD"

    SNAP_DISTANCE = "SNAP_DISTANCE"
    REPAIR_GAPS = "REPAIR_GAPS"
    GAP_TOLERANCE = "GAP_TOLERANCE"
    TOUCH_TOLERANCE = "TOUCH_TOLERANCE"
    DIRECT_XY_OBJECT_DISTANCE = "DIRECT_XY_OBJECT_DISTANCE"
    POINTS_OUTPUT = "POINTS_OUTPUT"
    OUTPUT = "OUTPUT"

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POLYGONS,
            "Objecten / polygonen (pand of perceel)",
            [QgsProcessing.TypeVectorPolygon],
        ))

        self.addParameter(QgsProcessingParameterFeatureSource(
            self.ADDRESS_POINTS,
            "Adrespuntenlaag",
            [QgsProcessing.TypeVectorPoint],
        ))

        self.addParameter(QgsProcessingParameterFeatureSource(
            self.NETWORK,
            "Routeringsnetwerk / tracé",
            [QgsProcessing.TypeVectorLine],
        ))

        self.addParameter(QgsProcessingParameterFile(
            self.EXCEL_FILE,
            "Excelbestand met X/Y",
            behavior=QgsProcessingParameterFile.File,
            extension="xlsx",
        ))

        self.addParameter(QgsProcessingParameterField(
            self.POINT_POSTCODE_FIELD,
            "Postcodeveld adrespunt",
            parentLayerParameterName=self.ADDRESS_POINTS,
        ))

        self.addParameter(QgsProcessingParameterField(
            self.POINT_HOUSE_FIELD,
            "Huisnummerveld adrespunt",
            parentLayerParameterName=self.ADDRESS_POINTS,
        ))

        self.addParameter(QgsProcessingParameterString(
            self.EXCEL_POSTCODE_FIELD,
            "Postcodekolom Excel",
            defaultValue="postcode",
        ))

        self.addParameter(QgsProcessingParameterString(
            self.EXCEL_HOUSE_FIELD,
            "Huisnummerkolom Excel",
            defaultValue="Huisnr",
        ))

        self.addParameter(QgsProcessingParameterString(
            self.EXCEL_X_FIELD,
            "X-kolom Excel",
            defaultValue="X",
        ))

        self.addParameter(QgsProcessingParameterString(
            self.EXCEL_Y_FIELD,
            "Y-kolom Excel",
            defaultValue="Y",
        ))

        self.addParameter(QgsProcessingParameterDistance(
            self.SNAP_DISTANCE,
            "Maximale snapafstand naar netwerk",
            defaultValue=200.0,
            parentParameterName=self.POLYGONS,
            minValue=0.0,
        ))

        self.addParameter(QgsProcessingParameterBoolean(
            self.REPAIR_GAPS,
            "Kleine tracé-onderbrekingen automatisch verbinden",
            defaultValue=True,
        ))

        self.addParameter(QgsProcessingParameterDistance(
            self.GAP_TOLERANCE,
            "Maximale gap-afstand tracéherstel",
            defaultValue=0.1,
            parentParameterName=self.NETWORK,
            minValue=0.0,
        ))

        self.addParameter(QgsProcessingParameterDistance(
            self.TOUCH_TOLERANCE,
            "Tolerantie: tracé raakt object",
            defaultValue=0.1,
            parentParameterName=self.POLYGONS,
            minValue=0.0,
        ))

        self.addParameter(QgsProcessingParameterDistance(
            self.DIRECT_XY_OBJECT_DISTANCE,
            "Directe afstand Excel X/Y naar object toestaan tot",
            defaultValue=2.0,
            parentParameterName=self.POLYGONS,
            minValue=0.0,
        ))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT,
            "Brils Routes Excel XY",
            QgsProcessing.TypeVectorLine,
        ))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.POINTS_OUTPUT,
            "Brils Routepunten Excel XY",
            QgsProcessing.TypeVectorPoint,
        ))




    def _shortest_line_point_to_polygon(self, point, poly_geom):
        point_geom = QgsGeometry.fromPointXY(QgsPointXY(point))

        try:
            line_geom = point_geom.shortestLine(poly_geom)
        except Exception:
            line_geom = None

        if line_geom is not None and not line_geom.isEmpty():
            if line_geom.isMultipart():
                lines = line_geom.asMultiPolyline()
                pts = lines[0] if lines else []
            else:
                pts = line_geom.asPolyline()

            if len(pts) >= 2:
                start_pt = QgsPointXY(pts[0])
                object_pt = QgsPointXY(pts[-1])
                return start_pt, object_pt, dist(start_pt, object_pt)

        object_pt = polygon_boundary_start_point(poly_geom, QgsPointXY(point))
        if object_pt is None:
            return None, None, None

        start_pt = QgsPointXY(point)
        return start_pt, object_pt, dist(start_pt, object_pt)

    def _shortest_line_polygon_to_segment(self, poly_geom, a, b):
        # Exacte benadering van QGIS "Kortste lijn tussen objecten":
        # bepaal de kortste lijn tussen pandgeometrie en één tracésegment.
        seg_geom = QgsGeometry.fromPolylineXY([a, b])

        try:
            line_geom = poly_geom.shortestLine(seg_geom)
        except Exception:
            line_geom = None

        if line_geom is not None and not line_geom.isEmpty():
            if line_geom.isMultipart():
                lines = line_geom.asMultiPolyline()
                pts = lines[0] if lines else []
            else:
                pts = line_geom.asPolyline()

            if len(pts) >= 2:
                start_pt = QgsPointXY(pts[0])
                network_pt = QgsPointXY(pts[-1])
                return start_pt, network_pt, dist(start_pt, network_pt)

        # Fallback: pandrand richting segment-midden.
        mid = QgsPointXY((a.x() + b.x()) / 2.0, (a.y() + b.y()) / 2.0)
        start_pt = polygon_boundary_start_point(poly_geom, mid)

        if start_pt is None:
            return None, None, None

        network_pt = closest_point_on_segment(start_pt, a, b)
        return start_pt, network_pt, dist(start_pt, network_pt)

    def _touching_network_connection_for_polygon(self, poly_geom, segments, spatial_index, max_search, touch_tolerance):
        if poly_geom is None or poly_geom.isEmpty():
            return None

        bbox = poly_geom.boundingBox()
        bbox.grow(max_search)
        candidate_ids = spatial_index.intersects(bbox)
        best = None

        for seg_id in candidate_ids:
            if seg_id < 0 or seg_id >= len(segments):
                continue

            a, b = segments[seg_id]
            seg_geom = QgsGeometry.fromPolylineXY([a, b])

            try:
                d = poly_geom.distance(seg_geom)
                touches = seg_geom.intersects(poly_geom) or d <= touch_tolerance
            except Exception:
                continue

            if not touches:
                continue

            start_pt, network_pt, conn_len = self._shortest_line_polygon_to_segment(poly_geom, a, b)

            if network_pt is None:
                continue

            # Als tracé raakt of binnen tolerantie ligt: prioriteit boven alles.
            # We voegen geen extra aansluitlijn toe; startpunt ligt op het tracé.
            conn_len = 0.0
            start_pt = network_pt

            if best is None or d < best["distance_to_polygon"]:
                best = {
                    "start": start_pt,
                    "network": network_pt,
                    "segment": seg_id,
                    "distance": conn_len,
                    "distance_to_polygon": d,
                    "seg_a": a,
                    "seg_b": b,
                    "mode": "TOUCHING_TRACE",
                }

        return best

    def _nearest_network_connection_for_polygon(self, poly_geom, segments, spatial_index, max_search, touch_tolerance=0.1):
        # Prioriteit 1: tracé dat object raakt/snijdt of binnen tolerantie ligt.
        touching = self._touching_network_connection_for_polygon(
            poly_geom,
            segments,
            spatial_index,
            max_search,
            touch_tolerance,
        )

        if touching is not None:
            return touching

        # Prioriteit 2: echte kortste lijn object -> tracé.
        if poly_geom is None or poly_geom.isEmpty():
            return None

        bbox = poly_geom.boundingBox()
        bbox.grow(max_search)
        candidate_ids = spatial_index.intersects(bbox)

        if not candidate_ids:
            centroid = QgsPointXY(poly_geom.centroid().asPoint())
            candidate_ids = spatial_index.nearestNeighbor(centroid, 100)

        best = None

        for seg_id in candidate_ids:
            if seg_id < 0 or seg_id >= len(segments):
                continue

            a, b = segments[seg_id]
            seg_geom = QgsGeometry.fromPolylineXY([a, b])

            try:
                geom_distance = poly_geom.distance(seg_geom)
            except Exception:
                continue

            if geom_distance > max_search:
                continue

            start_pt, network_pt, conn_len = self._shortest_line_polygon_to_segment(poly_geom, a, b)

            if start_pt is None or network_pt is None or conn_len is None:
                continue

            if best is None or conn_len < best["distance"]:
                best = {
                    "start": start_pt,
                    "network": network_pt,
                    "segment": seg_id,
                    "distance": conn_len,
                    "distance_to_polygon": geom_distance,
                    "seg_a": a,
                    "seg_b": b,
                    "mode": "SHORTEST_LINE",
                }

        return best

    def _add_segment_to_indices(self, graph, points, segments, spatial_index, a, b):
        a = QgsPointXY(a)
        b = QgsPointXY(b)

        if dist(a, b) <= 0.000001:
            add_edge(graph, points, a, b)
            return None

        seg_id = len(segments)
        segments.append((a, b))
        add_edge(graph, points, a, b)

        sf = QgsFeature()
        sf.setId(seg_id)
        sf.setGeometry(QgsGeometry.fromPolylineXY([a, b]))
        spatial_index.addFeature(sf)
        return seg_id

    def _prepare_polygon_connections(self, poly_data, base_graph, base_points, segments, spatial_index, max_snap, feedback, touch_tolerance):
        # Voor iedere pandpolygoon:
        # 1. kortste lijn pand -> tracé berekenen;
        # 2. lengte 0 bewaren, maar NIET als lijn toevoegen;
        # 3. lengte > 0 als tijdelijke aansluitlijn toevoegen;
        # 4. doeltracé topologisch splitsen op aansluitpunt.
        connections = {}
        made = 0
        zero = 0
        touching_count = 0
        failed = 0

        for fid, item in poly_data.items():
            conn = self._nearest_network_connection_for_polygon(item["geometry"], segments, spatial_index, max_snap, touch_tolerance)

            if conn is None:
                failed += 1
                continue

            if conn.get("mode") == "TOUCHING_TRACE":
                touching_count += 1

            start_pt = conn["start"]
            network_pt = conn["network"]
            seg_a = conn["seg_a"]
            seg_b = conn["seg_b"]

            # Split doelsegment op aansluitpunt, zodat routering daar echt kan starten.
            self._add_segment_to_indices(base_graph, base_points, segments, spatial_index, network_pt, seg_a)
            self._add_segment_to_indices(base_graph, base_points, segments, spatial_index, network_pt, seg_b)

            if conn["distance"] > 0.001:
                self._add_segment_to_indices(base_graph, base_points, segments, spatial_index, start_pt, network_pt)
                route_start = start_pt
                made += 1
            else:
                # Tracé raakt/snijdt pand al.
                # Geen 0-lengte aansluitlijn toevoegen; start op het netwerkpunt.
                add_edge(base_graph, base_points, network_pt, network_pt)
                route_start = network_pt
                zero += 1

            connections[fid] = {
                "start": route_start,
                "network": network_pt,
                "distance": conn["distance"],
            }

        if feedback:
            feedback.pushInfo(
                f"Object-aansluitingen: {made} toegevoegd, {zero} nul-lengte genegeerd, {touching_count} via rakend tracé, {failed} niet gelukt."
            )

        return connections

    def processAlgorithm(self, parameters, context, feedback):
        polygons = self.parameterAsSource(parameters, self.POLYGONS, context)
        address_points = self.parameterAsSource(parameters, self.ADDRESS_POINTS, context)
        network = self.parameterAsSource(parameters, self.NETWORK, context)

        excel_path = self.parameterAsFile(parameters, self.EXCEL_FILE, context)

        point_postcode_field = self.parameterAsString(parameters, self.POINT_POSTCODE_FIELD, context)
        point_house_field = self.parameterAsString(parameters, self.POINT_HOUSE_FIELD, context)

        excel_postcode_field = self.parameterAsString(parameters, self.EXCEL_POSTCODE_FIELD, context)
        excel_house_field = self.parameterAsString(parameters, self.EXCEL_HOUSE_FIELD, context)
        excel_x_field = self.parameterAsString(parameters, self.EXCEL_X_FIELD, context)
        excel_y_field = self.parameterAsString(parameters, self.EXCEL_Y_FIELD, context)

        max_snap = self.parameterAsDouble(parameters, self.SNAP_DISTANCE, context)
        repair_gaps = self.parameterAsBoolean(parameters, self.REPAIR_GAPS, context)
        gap_tolerance = self.parameterAsDouble(parameters, self.GAP_TOLERANCE, context)
        touch_tolerance = self.parameterAsDouble(parameters, self.TOUCH_TOLERANCE, context)
        direct_xy_object_distance = self.parameterAsDouble(parameters, self.DIRECT_XY_OBJECT_DISTANCE, context)

        if polygons is None or address_points is None or network is None:
            raise QgsProcessingException("Panden, adrespunten of netwerk kon niet worden gelezen.")

        if polygons.sourceCrs() != address_points.sourceCrs() or polygons.sourceCrs() != network.sourceCrs():
            raise QgsProcessingException("Panden, adrespunten en netwerk moeten hetzelfde CRS hebben.")

        feedback.pushInfo("Excelbestand inlezen...")
        excel_rows = self._read_xlsx_rows(excel_path)
        excel_lookup = self._build_excel_lookup(
            excel_rows,
            excel_postcode_field,
            excel_house_field,
            excel_x_field,
            excel_y_field,
        )
        feedback.pushInfo(f"Excel matches beschikbaar: {len(excel_lookup)}")

        feedback.pushInfo("Panden indexeren...")
        poly_index = QgsSpatialIndex()
        poly_data = {}

        invalid_polygon_count = 0

        for pf in polygons.getFeatures():
            geom = pf.geometry()

            if geom is None or geom.isEmpty():
                invalid_polygon_count += 1
                continue

            try:
                if hasattr(geom, "isGeosValid") and not geom.isGeosValid():
                    invalid_polygon_count += 1
                    continue
            except Exception:
                invalid_polygon_count += 1
                continue

            fid = int(pf.id())
            poly_data[fid] = {
                "feature": pf,
                "geometry": geom,
            }
            poly_index.addFeature(pf)

        if invalid_polygon_count:
            feedback.pushInfo(f"Ongeldige/lege polygonen overgeslagen: {invalid_polygon_count}. Repareer deze geometrieën indien nodig.")

        if not poly_data:
            raise QgsProcessingException("Geen geldige objectpolygonen gevonden.")

        feedback.pushInfo("Netwerk voorbereiden...")
        base_graph, base_points, segments, spatial_index = build_network(
            network,
            feedback,
            repair_gaps,
            gap_tolerance,
        )
        feedback.pushInfo(f"Netwerksegmenten vóór object-aansluitingen: {len(segments)}")

        polygon_connections = self._prepare_polygon_connections(
            poly_data,
            base_graph,
            base_points,
            segments,
            spatial_index,
            max_snap,
            feedback,
            touch_tolerance,
        )

        feedback.pushInfo(f"Netwerksegmenten na object-aansluitingen: {len(segments)}")

        fields = QgsFields()
        fields.append(QgsField("postcode", QVariant.String))
        fields.append(QgsField("huisnr", QVariant.String))
        fields.append(QgsField("match_key", QVariant.String))
        fields.append(QgsField("excel_x", QVariant.Double))
        fields.append(QgsField("excel_y", QVariant.Double))
        fields.append(QgsField("lengte_m", QVariant.Double))
        fields.append(QgsField("snap_a_m", QVariant.Double))
        fields.append(QgsField("snap_b_m", QVariant.Double))
        fields.append(QgsField("pand_trace_m", QVariant.Double))
        fields.append(QgsField("xy_object_m", QVariant.Double))
        fields.append(QgsField("status", QVariant.String))
        fields.append(QgsField("object_id", QVariant.String))
        fields.append(QgsField("adres_fid", QVariant.String))

        sink, dest_id = self.parameterAsSink(
            parameters,
            self.OUTPUT,
            context,
            fields,
            QgsWkbTypes.LineString,
            polygons.sourceCrs(),
        )

        point_fields = QgsFields()
        point_fields.append(QgsField("match_key", QVariant.String))
        point_fields.append(QgsField("punt_type", QVariant.String))
        point_fields.append(QgsField("postcode", QVariant.String))
        point_fields.append(QgsField("huisnr", QVariant.String))
        point_fields.append(QgsField("object_id", QVariant.String))

        point_sink, point_dest_id = self.parameterAsSink(
            parameters,
            self.POINTS_OUTPUT,
            context,
            point_fields,
            QgsWkbTypes.Point,
            polygons.sourceCrs(),
        )

        total = address_points.featureCount() or 1
        ok = 0
        failed = 0
        seen_keys = set()

        def add_route_point(match_key, point_type, postcode, huisnr, object_id, point):
            pf = QgsFeature(point_fields)
            pf["match_key"] = match_key
            pf["punt_type"] = point_type
            pf["postcode"] = postcode
            pf["huisnr"] = huisnr
            pf["object_id"] = str(object_id) if object_id is not None else ""
            pf.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(point)))
            point_sink.addFeature(pf)

        for idx, af in enumerate(address_points.getFeatures()):
            if feedback.isCanceled():
                break

            feedback.setProgress(int((idx / total) * 100))

            postcode = self._clean_postcode(af[point_postcode_field])
            huisnr = self._clean_house(af[point_house_field])
            match_key = self._make_key(postcode, huisnr)

            if match_key in seen_keys:
                feedback.pushInfo(f"{match_key} overgeslagen: dubbele adreskey in adrespuntlaag.")
                continue
            seen_keys.add(match_key)

            feat = QgsFeature(fields)
            feat["postcode"] = postcode
            feat["huisnr"] = huisnr
            feat["match_key"] = match_key
            feat["adres_fid"] = str(af.id())

            if match_key not in excel_lookup:
                feat["status"] = "FAILED_NO_EXCEL_MATCH"
                sink.addFeature(feat)
                failed += 1
                feedback.pushInfo(f"{match_key} FAILED: geen Excel match.")
                continue

            target = excel_lookup[match_key]
            target_pt = QgsPointXY(target["x"], target["y"])
            feat["excel_x"] = target["x"]
            feat["excel_y"] = target["y"]

            addr_geom = af.geometry()
            if addr_geom is None or addr_geom.isEmpty():
                feat["status"] = "FAILED_EMPTY_ADDRESS_POINT"
                sink.addFeature(feat)
                failed += 1
                continue

            if addr_geom.isMultipart():
                addr_points = addr_geom.asMultiPoint()
                if not addr_points:
                    feat["status"] = "FAILED_EMPTY_ADDRESS_POINT"
                    sink.addFeature(feat)
                    failed += 1
                    continue
                addr_pt = QgsPointXY(addr_points[0])
            else:
                addr_pt = QgsPointXY(addr_geom.asPoint())

            polygon_fid = self._find_containing_polygon(addr_pt, poly_index, poly_data)
            if polygon_fid is None:
                feat["status"] = "FAILED_NO_CONTAINING_OBJECT"
                sink.addFeature(feat)
                failed += 1
                feedback.pushInfo(f"{match_key} FAILED: geen object/polygoon rond adrespunt.")
                continue

            poly_geom = poly_data[polygon_fid]["geometry"]
            # V5.0.10:
            # Harde beslisregel vóór elke netwerksnap:
            # 1. Bereken directe kortste lijn Excel X/Y -> object/polygoon.
            # 2. Als deze binnen de ingestelde drempel valt: gebruik direct en stop.
            # 3. Alleen daarboven via tracé/routeringsnetwerk.
            xy_start_pt, object_end_pt, xy_object_m = self._shortest_line_point_to_polygon(target_pt, poly_geom)

            feat["xy_object_m"] = round(xy_object_m, 3) if xy_object_m is not None else None

            if xy_start_pt is None or object_end_pt is None:
                feat["status"] = "FAILED_XY_OBJECT_SHORTEST_LINE"
                feat["object_id"] = str(polygon_fid)
                sink.addFeature(feat)
                failed += 1
                feedback.pushInfo(f"{match_key} FAILED: geen kortste lijn Excel X/Y naar object.")
                continue

            add_route_point(match_key, "START_XY", postcode, huisnr, polygon_fid, target_pt)
            add_route_point(match_key, "EIND_OBJECT", postcode, huisnr, polygon_fid, object_end_pt)

            if xy_object_m <= direct_xy_object_distance:
                route_geom = QgsGeometry.fromPolylineXY([QgsPointXY(target_pt), QgsPointXY(object_end_pt)])
                snap_a = 0.0
                snap_b = 0.0
                status = "OK_DIRECT_XY_OBJECT"
                feat["pand_trace_m"] = 0.0
            else:
                if polygon_fid not in polygon_connections:
                    feat["status"] = "FAILED_NO_OBJECT_CONNECTION"
                    feat["object_id"] = str(polygon_fid)
                    sink.addFeature(feat)
                    failed += 1
                    feedback.pushInfo(f"{match_key} FAILED: geen object-aansluiting naar tracé.")
                    continue

                object_network_start = polygon_connections[polygon_fid]["start"]

                route_geom, snap_a, snap_b, status = route_between_points(
                    target_pt,
                    object_network_start,
                    base_graph,
                    base_points,
                    segments,
                    spatial_index,
                    max_snap,
                )

                if status == "OK" and route_geom is not None:
                    snap_b = polygon_connections[polygon_fid]["distance"]
                    feat["pand_trace_m"] = round(polygon_connections[polygon_fid]["distance"], 3)

            feat["status"] = status
            feat["object_id"] = str(polygon_fid)

            if status.startswith("OK") and route_geom is not None:
                feat["lengte_m"] = round(route_geom.length(), 3)
                feat["snap_a_m"] = round(snap_a, 3)
                feat["snap_b_m"] = round(snap_b, 3)
                feat.setGeometry(route_geom)
                ok += 1
                feedback.pushInfo(f"{match_key} {status} | {route_geom.length():.3f} m | xy-object {xy_object_m:.3f} m")
            else:
                failed += 1
                feedback.pushInfo(f"{match_key} {status}")

            sink.addFeature(feat)

        feedback.setProgress(100)
        feedback.pushInfo(f"Klaar. OK: {ok}. FAILED: {failed}.")
        return {self.OUTPUT: dest_id, self.POINTS_OUTPUT: point_dest_id}

    def _find_containing_polygon(self, point, poly_index, poly_data):
        point_geom = QgsGeometry.fromPointXY(point)
        candidate_ids = poly_index.intersects(point_geom.boundingBox())

        best_fid = None
        best_area = None

        for fid in candidate_ids:
            if fid not in poly_data:
                continue

            geom = poly_data[fid]["geometry"]

            if geom is None or geom.isEmpty():
                continue

            try:
                if hasattr(geom, "isGeosValid") and not geom.isGeosValid():
                    continue

                contains = geom.contains(point_geom) or geom.intersects(point_geom)
            except Exception:
                continue

            if not contains:
                continue

            try:
                area = geom.area()
            except Exception:
                area = 0

            # Bij perceel + pand overlap of meerdere objecten:
            # kies het kleinste object waar het adrespunt in ligt.
            if best_fid is None or area < best_area:
                best_fid = fid
                best_area = area

        return best_fid

    def _make_key(self, postcode, huisnr):
        return f"{self._clean_postcode(postcode)}_{self._clean_house(huisnr)}"

    def _clean_postcode(self, value):
        if value is None:
            return ""
        return re.sub(r"\\s+", "", str(value)).upper()

    def _clean_house(self, value):
        if value is None:
            return ""
        txt = str(value).strip()
        if txt.endswith(".0"):
            txt = txt[:-2]
        return txt

    def _build_excel_lookup(self, rows, postcode_col, house_col, x_col, y_col):
        lookup = {}

        for row in rows:
            cols_lower = {str(k).strip().lower(): k for k in row.keys()}

            pc_key = cols_lower.get(postcode_col.strip().lower())
            hn_key = cols_lower.get(house_col.strip().lower())
            x_key = cols_lower.get(x_col.strip().lower())
            y_key = cols_lower.get(y_col.strip().lower())

            if pc_key is None or hn_key is None or x_key is None or y_key is None:
                continue

            postcode = self._clean_postcode(row.get(pc_key))
            huisnr = self._clean_house(row.get(hn_key))

            try:
                x = float(str(row.get(x_key)).replace(",", "."))
                y = float(str(row.get(y_key)).replace(",", "."))
            except Exception:
                continue

            lookup[self._make_key(postcode, huisnr)] = {"x": x, "y": y}

        return lookup

    def _read_xlsx_rows(self, path):
        # V5.0.1: stabiele Excel-reader via openpyxl.
        # QGIS 3.44/Python 3.12 bevat openpyxl normaal gesproken in de omgeving.
        try:
            import openpyxl
        except Exception as exc:
            raise QgsProcessingException(
                "openpyxl kon niet worden geladen. "
                "Installeer openpyxl in de QGIS Python omgeving of exporteer Excel naar .xlsx opnieuw."
            ) from exc

        workbook = openpyxl.load_workbook(path, read_only=True, data_only=True)
        sheet = workbook.active

        rows_iter = sheet.iter_rows(values_only=True)
        headers_raw = next(rows_iter, None)

        if not headers_raw:
            return []

        headers = []
        for value in headers_raw:
            if value is None:
                headers.append("")
            else:
                headers.append(str(value).strip())

        result = []

        for row in rows_iter:
            item = {}

            for idx, value in enumerate(row):
                if idx >= len(headers):
                    continue

                header = headers[idx]
                if not header:
                    continue

                item[header] = "" if value is None else value

            if item:
                result.append(item)

        return result

    def name(self):
        return "route_panden_naar_excel_xy"

    def displayName(self):
        return "Route Panden Naar Excel XY"

    def group(self):
        return "Routing"

    def groupId(self):
        return "routing"

    def createInstance(self):
        return RoutePandenNaarExcelXYAlgorithm()
