from qgis.core import QgsProcessingProvider
from .route_lines_algorithm import RouteLinesAlgorithm
from .route_buildings_algorithm import RouteBuildingsAlgorithm
from .route_excel_xy_algorithm import RoutePandenNaarExcelXYAlgorithm
from .route_excel_xy_direct_algorithm import RouteObjectenNaarExcelXYDirectAlgorithm

class ProjectBrilsProvider(QgsProcessingProvider):
    def loadAlgorithms(self):
        self.addAlgorithm(RouteLinesAlgorithm())
        self.addAlgorithm(RouteBuildingsAlgorithm())
        self.addAlgorithm(RoutePandenNaarExcelXYAlgorithm())
        self.addAlgorithm(RouteObjectenNaarExcelXYDirectAlgorithm())

    def id(self): return "project_brils"
    def name(self): return "Project Brils"
    def longName(self): return "Project Brils"
